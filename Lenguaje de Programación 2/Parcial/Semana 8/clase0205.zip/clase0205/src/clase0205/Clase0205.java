package clase0205;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class Clase0205 {
    public static void main(String[] args) throws Exception{
       Class.forName("com.mysql.jdbc.Driver");
Connection con = 
DriverManager.getConnection
("jdbc:mysql://127.0.0.1/LP2", 
        "root", "123456");

        
        JasperReport jr = 
       (JasperReport) 
       JRLoader.loadObjectFromFile
    (Clase0205.class.getResource
   ("/clase0205/reporte4.jasper").getFile());

        HashMap hm = new HashMap();
        hm.put("parametroTitulo", "j");
        
       JasperPrint impresion 
 =JasperFillManager.fillReport(
    jr, null, con);

       JasperViewer viewer = 
         new JasperViewer(impresion);
        viewer.setVisible(true);

    }
    
}
