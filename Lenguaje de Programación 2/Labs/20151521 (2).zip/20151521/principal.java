public class principal{
	public static void main(){
		Sede clinica = new Sede("Los rosales", "28 DE JULIO");
		Especialidad e1 = new Especialidad ("trauma", "Q");
	}
}