public interface IConsultable{
	String consultarDatos();
}