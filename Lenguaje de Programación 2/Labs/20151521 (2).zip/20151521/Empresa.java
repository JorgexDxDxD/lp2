import java.util.List;
import java.util.ArrayList;
public class Empresa{
	private ArrayList <Sede> Lima;
	private ArrayList <Sede> Trujillo;
	private ArrayList <Sede> Chiclayo;
	
	public Empresa(){
			Lima = new ArrayList <Sede>();
			Trujillo = new ArrayList <Sede>();
			Chiclayo = new ArrayList <Sede>();
	}
}