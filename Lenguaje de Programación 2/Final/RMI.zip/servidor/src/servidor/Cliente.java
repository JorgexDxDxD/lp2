package servidor;

public class Cliente {
   public static void main(String[] args){
        try{
        InterfazRemota ir = (InterfazRemota) 
            java.rmi.Naming.lookup("//10.100.248.147:1234/rmi");
        ir.saludar("Miguel");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
   }
}
