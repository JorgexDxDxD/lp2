package servidor;
public interface InterfazRemota extends java.rmi.Remote {
    public void saludar(String nombre) 
            throws java.rmi.RemoteException;
}