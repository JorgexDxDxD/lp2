package servidor;

public class Servidor {

    public static void main(String[] args) {
        try{
            InterfazRemota i = new implementacion();
            java.rmi.Naming.rebind("//10.100.248.147:1234/rmi", i);
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
}
