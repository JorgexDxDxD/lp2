package servidor;

import java.rmi.RemoteException;

public class implementacion extends 
        java.rmi.server.UnicastRemoteObject 
        implements InterfazRemota{

    public implementacion() throws java.rmi.RemoteException{
        
    }
    
    @Override
    public void saludar(String nombre) throws RemoteException {
        System.out.println("HOLA "+nombre);
    }
    
}
