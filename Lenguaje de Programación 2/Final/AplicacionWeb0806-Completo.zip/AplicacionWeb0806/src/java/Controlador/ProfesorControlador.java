package Controlador;

import AccesoDatos.ProfesorDA;
import Modelo.Profesor;
import java.io.Serializable;
import java.util.ArrayList;

public class ProfesorControlador implements Serializable{

    public void eliminarProfesor(){
        accesoDatos.eliminarProfesor(profesor);
    }
    
    public String editarProfesor(){
        accesoDatos.editarProfesor(profesor);
        return "listar";
    }
    
    public ArrayList<Profesor> getProfesores(){
        return accesoDatos.listarProfesores();
    }
    
    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public ProfesorDA getAccesoDatos() {
        return accesoDatos;
    }

    public void setAccesoDatos(ProfesorDA accesoDatos) {
        this.accesoDatos = accesoDatos;
    }
    private Profesor profesor;
    private ProfesorDA accesoDatos;
    
    public ProfesorControlador(){
        profesor = new Profesor();
        accesoDatos = new ProfesorDA();
    }
    
    public String registrarProfesor(){
        accesoDatos.registrarProfesor(profesor);
        return "listar";
    }
}
