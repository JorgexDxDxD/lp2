
package AccesoDatos;

import Modelo.Profesor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ProfesorDA {
    
    public void eliminarProfesor(Profesor p){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/lp2?useSSL=false", "root", "123456");
            String sql = "DELETE FROM PROFESOR WHERE ID = "+
                    p.getId();
            Statement st = c.createStatement();
            st.executeUpdate(sql);
            c.close();
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    public void registrarProfesor(Profesor p) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/lp2?useSSL=false", "root", "123456");
            String sql = "INSERT INTO PROFESOR (NOMBRE, APELLIDO) "
                    + "VALUES ('"+p.getNombre()+"','"+
            p.getApellido()+"')";
            Statement st = c.createStatement();
            st.executeUpdate(sql);
            c.close();
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    public void editarProfesor(Profesor p) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/lp2?useSSL=false", "root", "123456");
            String sql = "UPDATE PROFESOR SET NOMBRE = '"+
                    p.getNombre() + "', APELLIDO = '"+p.getApellido()
                    +"' WHERE ID = "+p.getId();
            Statement st = c.createStatement();
            st.executeUpdate(sql);
            c.close();
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
    
    public ArrayList<Profesor> listarProfesores(){
        ArrayList<Profesor> lista = new ArrayList<Profesor>();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/lp2?useSSL=false", "root", "123456");
            String sql = "SELECT ID, NOMBRE, APELLIDO FROM"
                    + " PROFESOR";
            Statement st = c.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                Profesor p = new Profesor();
                p.setId(rs.getInt("ID"));
                p.setNombre(rs.getString("NOMBRE"));
                p.setApellido(rs.getString("APELLIDO"));
                lista.add(p);
            }
            c.close();
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
        return lista;
        
    }
}
