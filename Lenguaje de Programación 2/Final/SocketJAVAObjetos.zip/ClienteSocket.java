import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClienteSocket {
    public static void main(String[] args) {
        try{
            Socket so = new Socket("127.0.0.1",1234);
            ObjectOutputStream salida = new ObjectOutputStream (so.getOutputStream());
            persona p1 = new persona(1,"Pablo Gutierrez");
            salida.writeObject(p1);	
            salida.flush();
            salida.close();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}