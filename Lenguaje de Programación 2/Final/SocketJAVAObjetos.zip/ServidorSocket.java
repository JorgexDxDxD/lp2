import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.ObjectInputStream;

public class ServidorSocket {
    public static void main(String[] args) {
        try{
			Socket so = new Socket();
			ServerSocket ss = new ServerSocket(1234);
			while(true){
				System.out.println("En espera de conexion...");
				so = ss.accept();
				ObjectInputStream input = new ObjectInputStream(so.getInputStream());
				persona p1 = (persona) input.readObject();
				System.out.println(p1.getId() + " " + p1.getNombre());
			}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
    }
}