using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

public class Server
{
	public static void Main(string[] args)
    {
		IPAddress ip = IPAddress.Parse("127.0.0.1");
		TcpListener canal = new TcpListener(ip, 1234);
		canal.Start();
		try
		{
			while(true)
			{
				System.Console.WriteLine("Esperando conexion....");
				TcpClient cliente = canal.AcceptTcpClient();
				NetworkStream stream = cliente.GetStream();
				//Recibe el mensaje del cliente
				StreamReader sr = new StreamReader(stream);
				System.Console.WriteLine(sr.ReadLine());	
				//Envia el mensaje al cliente
				StreamWriter sw = new StreamWriter(stream);
				sw.WriteLine("Mensaje desde el server...");
				sw.Flush();
			}
		}catch (Exception ex)
		{
			System.Console.WriteLine(ex.Message);
			System.Console.Read();
		}
	}
}