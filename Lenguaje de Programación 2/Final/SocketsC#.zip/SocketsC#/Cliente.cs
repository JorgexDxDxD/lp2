﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

public class Cliente
{
	public static void Main(string[] args)
	{
		try{
			TcpClient cliente = new TcpClient("127.0.0.1", 1234);
			NetworkStream stream = cliente.GetStream();
            StreamWriter sw = new StreamWriter(stream);
			//Envia el mensaje al servidor
            sw.WriteLine("Mensaje desde el cliente..");
            sw.Flush();
			//Recibe el mensaje del servidor
			StreamReader sr = new StreamReader(stream);
			System.Console.WriteLine(sr.ReadLine());
		}catch(Exception ex)
		{
			System.Console.WriteLine(ex.Message);
			System.Console.Read();
		}
	}
}