using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;

public class ObjetoRemoto : System.MarshalByRefObject, InterfazRemota{
	public void saludar(string nombre){
        System.Console.WriteLine(nombre);
	}
	public string saludar2(){
        return "LP2";
	}
}