using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;

public class Server{
	public static void Main(string[] args)
	{
        TcpServerChannel canal =
        new TcpServerChannel(1234);
		ChannelServices.RegisterChannel(canal,false);
		RemotingConfiguration.RegisterWellKnownServiceType(typeof(ObjetoRemoto), "service", WellKnownObjectMode.SingleCall);
        System.Console.WriteLine("Esperando conexion...");
        System.Console.ReadLine();
	}
}