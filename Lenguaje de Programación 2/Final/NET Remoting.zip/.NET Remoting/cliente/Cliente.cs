using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Text;
using System.Threading.Tasks;

public class Cliente{
	public static void Main(string[] args){
        try{
			TcpClientChannel canal = new TcpClientChannel();
			ChannelServices.RegisterChannel (canal, false);
			string url = "tcp://127.0.0.1:1234/service";
			InterfazRemota ir = (InterfazRemota) Activator.GetObject (typeof(InterfazRemota),url);
			ir.saludar("Hola desde el cliente...");
		}catch(Exception ex){
			System.Console.WriteLine(ex.Message);
		}
	}
}