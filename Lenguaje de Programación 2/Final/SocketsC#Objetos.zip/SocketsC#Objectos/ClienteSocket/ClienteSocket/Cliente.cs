﻿using Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace ClienteSocket
{
    public class Cliente
    {
        public static void Main()
        {
            try
            {
                TcpClient cliente = new TcpClient("127.0.0.1", 1234);
                NetworkStream stream = cliente.GetStream();
                Persona p = new Persona(1,"Juan Perez");
                BinaryFormatter bf = new BinaryFormatter();
                bf.Serialize(stream, p);
                stream.Flush();
                stream.Close();
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
                System.Console.Read();
            }
        }
    }
}
