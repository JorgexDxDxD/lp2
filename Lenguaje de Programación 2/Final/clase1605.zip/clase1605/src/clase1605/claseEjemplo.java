package clase1605;
public class claseEjemplo implements Runnable{
public static void main(String[] args) throws Exception{
    Runnable e = new claseEjemplo();
    Thread t = new Thread(e,"Hilo 1");
    t.start();
    t.join();
    t.join();
    System.out.print(t.getName());
    System.out.println(", estado = "+ t.isAlive());	
}
	
public void run(){
    Thread t = Thread.currentThread();
    System.out.print(t.getName());
    System.out.println(", estado = "+ t.isAlive());
}	
}
