package clase1605;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Freddy
 */
public class cuadrados implements Runnable {
    public void run(){
        for(int i=1;i<=50; i++){
            System.out.println(
            i+" * "+i+" = "+i*i);
        }
    }
}
