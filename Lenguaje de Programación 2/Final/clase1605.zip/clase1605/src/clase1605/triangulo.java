package clase1605;

public class triangulo extends Thread{
    public void run(){
        int i = 50;
        for(int j=1;j<=i;j++){
            for(int z=0;z<j;z++){
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
