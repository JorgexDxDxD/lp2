/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase1605;

/**
 *
 * @author Freddy
 */
public class Clase1605 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
          triangulo t = new triangulo();
          t.start();
          cuadrados c = new cuadrados();
          Thread hilo = new Thread(c);
          hilo.start();
          
//        timer t = new timer();
//        t.start();
    }
    
}
