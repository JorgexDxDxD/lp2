
package clase1605;


public class timer extends Thread{
    public void run(){
        int i = 1;
        try{
            while(true){
                System.out.println(i);
                i++;
                sleep(1000);
            }
        }catch(Exception e){}
    }
}
