package banco;

public class ATM {
    public void retirar(cuenta c, float cantidad, String nombre) {
        if (c.deducir(cantidad)){
			  dispensar(cantidad, nombre);
		     System.out.println(nombre + "Imprime recibo");
}
        else
            System.out.println(nombre + "Su cuenta no tiene esa cantidad");
}
    public void dispensar(float cantidad, String nombre){
        System.out.println(nombre + "ATM dispensa la cantidad de: "+cantidad);
    }
}
