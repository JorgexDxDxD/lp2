
package banco;

import banco.cuenta;
import banco.ATM;



public class ejemploBanco implements Runnable{
    private static cuenta c;
    private static ATM atm;
    public static void main (String[] args) throws Exception{
        c = new cuenta(500);
        atm = new ATM();
        Thread esposo = new Thread(new ejemploBanco(),"Esposo: ");
        Thread esposa = new Thread(new ejemploBanco(),"Esposa: ");
	esposa.start();
        esposo.start();
    }
    public void run(){
        atm.retirar(c, 400, Thread.currentThread().getName());
    }
}

