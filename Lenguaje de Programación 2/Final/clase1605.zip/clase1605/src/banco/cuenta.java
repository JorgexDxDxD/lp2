package banco;

public class cuenta {
    private float total;
    public cuenta(float total){
        this.total = total;
    }
    public synchronized boolean deducir(float cantidad){
        if (cantidad <= total){
            total -= cantidad;
            return true;
        }
        return false;
    }
    public float getTotal(){
        return this.total;
    }
}

