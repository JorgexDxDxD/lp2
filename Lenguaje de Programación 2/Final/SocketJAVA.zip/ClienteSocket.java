import java.io.DataOutputStream;
import java.net.Socket;

public class ClienteSocket {
    public static void main(String[] args) {
        try{
            Socket so = new Socket("127.0.0.1",1234);
            DataOutputStream salida = new DataOutputStream (so.getOutputStream());
            String mensaje = "Hola desde cliente...";
            salida.writeUTF(mensaje);	
            salida.flush();
            salida.close();
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}