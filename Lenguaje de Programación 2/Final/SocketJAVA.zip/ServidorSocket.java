import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorSocket {
    public static void main(String[] args) {
        try{
			Socket so = new Socket();
			ServerSocket ss = new ServerSocket(1234);
			while(true){
				System.out.println("En espera de conexion...");
				so = ss.accept();
				DataInputStream input = new DataInputStream(so.getInputStream());			
				System.out.println(input.readUTF());
			}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
    }
}