
package AccesoDatos;

import Modelo.Profesor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class ProfesorDA {
    public void registrarProfesor(Profesor p) {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection c = DriverManager.getConnection
        ("jdbc:mysql://127.0.0.1:3306/lp2?useSSL=false", "root", "123456");
            String sql = "INSERT INTO PROFESOR (NOMBRE, APELLIDO) "
                    + "VALUES ('"+p.getNombre()+"','"+
            p.getApellido()+"')";
            Statement st = c.createStatement();
            st.executeUpdate(sql);
        }catch(Exception ex){
            System.out.println(ex.toString());
        }
    }
}
