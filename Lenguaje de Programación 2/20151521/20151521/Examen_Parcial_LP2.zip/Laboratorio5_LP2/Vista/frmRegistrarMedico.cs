﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vista
{
    
    public partial class frmRegistrarMedico : Form
    {
        public enum Estado
        {
            Inicial, Nuevo, Deshabilitado
        }
        public frmRegistrarMedico()
        {
            InitializeComponent();
            estadoComponentes(Estado.Inicial);
        }

        public void estadoComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    btnNuevo.Enabled = true;
                    btnGuardar.Enabled = false;
                    btnCancelar.Enabled = false;
                    btnBuscar.Enabled = true;
                    txtID.Enabled = false;
                    txtDNI.Enabled = false;
                    txtNombre.Enabled = false;
                    txtApellido.Enabled = false;
                    rbMasculino.Enabled = false;
                    rbFemenino.Enabled = false;
                    txtEdad.Enabled = false;
                    cboEstadoCivil.Enabled = false;
                    txtSalario.Enabled = false;
                    rbTC.Enabled = false;
                    rbTP.Enabled = false;
                    txtColegiatura.Enabled = false;
                    cbEspecialidad.Enabled = false;
                    limpiarComponentes();
                    break;
                case Estado.Nuevo:
                    btnNuevo.Enabled = false;
                    btnGuardar.Enabled = true;
                    btnCancelar.Enabled = true;
                    btnBuscar.Enabled = true;
                    txtID.Enabled = false;
                    txtDNI.Enabled = true;
                    txtNombre.Enabled = true;
                    txtApellido.Enabled = true;
                    rbMasculino.Enabled = true;
                    rbFemenino.Enabled = true;
                    txtEdad.Enabled = true;
                    cboEstadoCivil.Enabled = true;
                    txtSalario.Enabled = true;
                    rbTC.Enabled = true;
                    rbTP.Enabled = true;
                    txtColegiatura.Enabled = true;
                    cbEspecialidad.Enabled = true;
                    limpiarComponentes();
                    break;
                case Estado.Deshabilitado:
                    btnNuevo.Enabled = true;
                    btnGuardar.Enabled = false;
                    btnCancelar.Enabled = false;
                    btnBuscar.Enabled = true;
                    btnGuardar.Enabled = false;
                    btnCancelar.Enabled = false;
                    btnBuscar.Enabled = true;
                    txtID.Enabled = false;
                    txtDNI.Enabled = false;
                    txtNombre.Enabled = false;
                    txtApellido.Enabled = false;
                    rbMasculino.Enabled = false;
                    rbFemenino.Enabled = false;
                    txtEdad.Enabled = false;
                    cboEstadoCivil.Enabled = false;
                    txtSalario.Enabled = false;
                    rbTC.Enabled = false;
                    rbTP.Enabled = false;
                    txtColegiatura.Enabled = false;
                    cbEspecialidad.Enabled = false;
                    break;
            }
        }

        public void limpiarComponentes()
        {
            txtID.Text = "";
            txtDNI.Text = "";
            txtNombre.Text = "";
            txtApellido.Text = "";
            rbMasculino.Checked = false;
            rbFemenino.Checked = false;
            txtEdad.Text = "";
            cboEstadoCivil.SelectedIndex = -1;
            txtSalario.Text = "";
            rbTC.Checked = false;
            rbTP.Checked = false;
            txtColegiatura.Text = "";
            cbEspecialidad.SelectedIndex = -1;
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            estadoComponentes(Estado.Nuevo);
            
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            frmBuscarMedico formBuscarMedico = new frmBuscarMedico();
            if (formBuscarMedico.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            estadoComponentes(Estado.Deshabilitado);
            MessageBox.Show("Se ha registrado con exito","Mensaje",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            estadoComponentes(Estado.Deshabilitado);
        }
    }
}
