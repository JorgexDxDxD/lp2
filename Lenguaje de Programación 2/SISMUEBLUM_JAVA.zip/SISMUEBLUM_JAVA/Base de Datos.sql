-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: quilla.lab.inf.pucp.edu.pe    Database: inf282g4
-- ------------------------------------------------------
-- Server version	5.5.54

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Almacen`
--

DROP TABLE IF EXISTS `Almacen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Almacen` (
  `Local_idLocal` int(11) NOT NULL AUTO_INCREMENT,
  `Empresa_ruc` int(11) NOT NULL,
  PRIMARY KEY (`Local_idLocal`),
  CONSTRAINT `fk_Almacen_Local1` FOREIGN KEY (`Local_idLocal`) REFERENCES `Local` (`idLocal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Almacen`
--

LOCK TABLES `Almacen` WRITE;
/*!40000 ALTER TABLE `Almacen` DISABLE KEYS */;
/*!40000 ALTER TABLE `Almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Cliente`
--

DROP TABLE IF EXISTS `Cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Cliente` (
  `codigoCliente` int(11) NOT NULL AUTO_INCREMENT,
  `telefono` varchar(15) NOT NULL,
  `correo` varchar(30) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `fechaDeRegistro` date NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`codigoCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Cliente`
--

LOCK TABLES `Cliente` WRITE;
/*!40000 ALTER TABLE `Cliente` DISABLE KEYS */;
INSERT INTO `Cliente` VALUES (1,'12312312','asdas@asd.com','av asdasdas 123','0000-00-00',1),(2,'123123','asd@pasd.com','av dsa 32','0000-00-00',1);
/*!40000 ALTER TABLE `Cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Color`
--

DROP TABLE IF EXISTS `Color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Color` (
  `idColor` int(11) NOT NULL AUTO_INCREMENT,
  `nombreColor` varchar(15) NOT NULL,
  PRIMARY KEY (`idColor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Color`
--

LOCK TABLES `Color` WRITE;
/*!40000 ALTER TABLE `Color` DISABLE KEYS */;
INSERT INTO `Color` VALUES (1,'Rosadito'),(2,'Moradito'),(3,'Negrito');
/*!40000 ALTER TABLE `Color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ComponenteKit`
--

DROP TABLE IF EXISTS `ComponenteKit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ComponenteKit` (
  `cantidad` int(11) NOT NULL,
  `Kit_Producto_codigo` int(11) NOT NULL,
  `Producto_codigo` int(11) NOT NULL,
  PRIMARY KEY (`Kit_Producto_codigo`,`Producto_codigo`),
  KEY `fk_ComponenteKit_Producto1_idx` (`Producto_codigo`),
  CONSTRAINT `fk_ComponenteKit_Kit1` FOREIGN KEY (`Kit_Producto_codigo`) REFERENCES `Kit` (`Producto_codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ComponenteKit_Producto1` FOREIGN KEY (`Producto_codigo`) REFERENCES `Producto` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ComponenteKit`
--

LOCK TABLES `ComponenteKit` WRITE;
/*!40000 ALTER TABLE `ComponenteKit` DISABLE KEYS */;
/*!40000 ALTER TABLE `ComponenteKit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DetalleProd`
--

DROP TABLE IF EXISTS `DetalleProd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DetalleProd` (
  `Producto_codigo` int(11) NOT NULL AUTO_INCREMENT,
  `cantidad` int(11) NOT NULL,
  `Local_idExhibicion` int(11) NOT NULL,
  PRIMARY KEY (`Producto_codigo`,`Local_idExhibicion`),
  KEY `fk_DetalleProd_Local1_idx` (`Local_idExhibicion`),
  CONSTRAINT `fk_DetalleProd_Exhibicion1` FOREIGN KEY (`Local_idExhibicion`) REFERENCES `Almacen` (`Local_idLocal`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_DetalleProd_Producto1` FOREIGN KEY (`Producto_codigo`) REFERENCES `Producto` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DetalleProd`
--

LOCK TABLES `DetalleProd` WRITE;
/*!40000 ALTER TABLE `DetalleProd` DISABLE KEYS */;
/*!40000 ALTER TABLE `DetalleProd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DetalleVenta`
--

DROP TABLE IF EXISTS `DetalleVenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DetalleVenta` (
  `Venta_idVenta` int(11) NOT NULL,
  `Producto_codigo` int(11) NOT NULL,
  `cantidad` double NOT NULL,
  `Venta_Vendedor_Usuario_codigoUsuario` int(11) NOT NULL,
  PRIMARY KEY (`Venta_idVenta`,`Producto_codigo`),
  KEY `fk_Venta_has_Producto_Producto1_idx` (`Producto_codigo`),
  KEY `fk_DetalleVenta_Venta1_idx` (`Venta_idVenta`),
  CONSTRAINT `fk_DetalleVenta_Venta1` FOREIGN KEY (`Venta_idVenta`) REFERENCES `Venta` (`idVenta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Venta_has_Producto_Producto1` FOREIGN KEY (`Producto_codigo`) REFERENCES `Producto` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DetalleVenta`
--

LOCK TABLES `DetalleVenta` WRITE;
/*!40000 ALTER TABLE `DetalleVenta` DISABLE KEYS */;
/*!40000 ALTER TABLE `DetalleVenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Empresa`
--

DROP TABLE IF EXISTS `Empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Empresa` (
  `ruc` varchar(10) NOT NULL,
  `direccionPrinc` varchar(50) NOT NULL,
  PRIMARY KEY (`ruc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Empresa`
--

LOCK TABLES `Empresa` WRITE;
/*!40000 ALTER TABLE `Empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `Empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Exhibicion`
--

DROP TABLE IF EXISTS `Exhibicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Exhibicion` (
  `Local_idLocal` int(11) NOT NULL AUTO_INCREMENT,
  `diaIni` varchar(10) NOT NULL,
  `diaFin` varchar(10) NOT NULL,
  `horaIni` time NOT NULL,
  `horaFin` time NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `Cliente_codigoCliente` int(11) DEFAULT NULL,
  PRIMARY KEY (`Local_idLocal`),
  KEY `fk_Exhibicion_Cliente1_idx` (`Cliente_codigoCliente`),
  CONSTRAINT `fk_Exhibicion_Cliente1` FOREIGN KEY (`Cliente_codigoCliente`) REFERENCES `Cliente` (`codigoCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Exhibicion_Local1` FOREIGN KEY (`Local_idLocal`) REFERENCES `Local` (`idLocal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Exhibicion`
--

LOCK TABLES `Exhibicion` WRITE;
/*!40000 ALTER TABLE `Exhibicion` DISABLE KEYS */;
/*!40000 ALTER TABLE `Exhibicion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Gerente`
--

DROP TABLE IF EXISTS `Gerente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Gerente` (
  `Usuario_codigoUsuario` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Usuario_codigoUsuario`),
  CONSTRAINT `fk_Gerente_Usuario` FOREIGN KEY (`Usuario_codigoUsuario`) REFERENCES `Usuario` (`codigoUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Gerente`
--

LOCK TABLES `Gerente` WRITE;
/*!40000 ALTER TABLE `Gerente` DISABLE KEYS */;
INSERT INTO `Gerente` VALUES (1),(2),(6);
/*!40000 ALTER TABLE `Gerente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Juridico`
--

DROP TABLE IF EXISTS `Juridico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Juridico` (
  `Cliente_codigoCliente` int(11) NOT NULL AUTO_INCREMENT,
  `ruc` varchar(12) NOT NULL,
  `razon` varchar(45) NOT NULL,
  `representante` varchar(45) NOT NULL,
  PRIMARY KEY (`Cliente_codigoCliente`),
  CONSTRAINT `fk_Juridico_Cliente1` FOREIGN KEY (`Cliente_codigoCliente`) REFERENCES `Cliente` (`codigoCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Juridico`
--

LOCK TABLES `Juridico` WRITE;
/*!40000 ALTER TABLE `Juridico` DISABLE KEYS */;
INSERT INTO `Juridico` VALUES (1,'123124124','asdadasd','av uno 11'),(2,'12312412','grgergegr','av dos 22');
/*!40000 ALTER TABLE `Juridico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Kit`
--

DROP TABLE IF EXISTS `Kit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Kit` (
  `Producto_codigo` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`Producto_codigo`),
  CONSTRAINT `fk_Kit_Producto1` FOREIGN KEY (`Producto_codigo`) REFERENCES `Producto` (`codigo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Kit`
--

LOCK TABLES `Kit` WRITE;
/*!40000 ALTER TABLE `Kit` DISABLE KEYS */;
/*!40000 ALTER TABLE `Kit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Local`
--

DROP TABLE IF EXISTS `Local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Local` (
  `idLocal` int(11) NOT NULL AUTO_INCREMENT,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  PRIMARY KEY (`idLocal`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Local`
--

LOCK TABLES `Local` WRITE;
/*!40000 ALTER TABLE `Local` DISABLE KEYS */;
INSERT INTO `Local` VALUES (5,'San Borja 123 los Pericos','998665335'),(6,'San Borja 123 los Pericos','998665335'),(7,'San Borja 123 los Pericos','998665335'),(8,'San Borja 123 los Pericos','998665335'),(9,'San Borja 123 los Pericos','998665335'),(10,'San Borja 123 los Pericos','998665335'),(11,'San Borja 123 los Pericos','998665335'),(12,'San Borja 123 los Pericos','998665335'),(13,'San Borja 123 los Pericos','998665335'),(14,'San Borja 123 los Pericos','998665335'),(15,'San Borja 123 los Pericos','998665335'),(16,'San Borja 123 los Pericos','998665335'),(17,'San Borja 123 los Pericos','998665335'),(18,'San Borja 123 los Pericos','998665335'),(19,'San Borja 123 los Pericos','998665335'),(20,'San Borja 123 los Pericos','998665335');
/*!40000 ALTER TABLE `Local` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Natural`
--

DROP TABLE IF EXISTS `Natural`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Natural` (
  `Cliente_codigoCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `apellidoPaterno` varchar(60) NOT NULL,
  `apellidoMaterno` varchar(60) NOT NULL,
  `dni` varchar(10) NOT NULL,
  PRIMARY KEY (`Cliente_codigoCliente`),
  CONSTRAINT `fk_Natural_Cliente1` FOREIGN KEY (`Cliente_codigoCliente`) REFERENCES `Cliente` (`codigoCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Natural`
--

LOCK TABLES `Natural` WRITE;
/*!40000 ALTER TABLE `Natural` DISABLE KEYS */;
/*!40000 ALTER TABLE `Natural` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pais`
--

DROP TABLE IF EXISTS `Pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pais` (
  `idPais` int(11) NOT NULL AUTO_INCREMENT,
  `nombrePais` varchar(60) NOT NULL,
  PRIMARY KEY (`idPais`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pais`
--

LOCK TABLES `Pais` WRITE;
/*!40000 ALTER TABLE `Pais` DISABLE KEYS */;
INSERT INTO `Pais` VALUES (1,'Austria');
/*!40000 ALTER TABLE `Pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Producto`
--

DROP TABLE IF EXISTS `Producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Producto` (
  `codigo` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `familia` varchar(80) NOT NULL,
  `precio` double NOT NULL,
  `Proveedor_idProveedor` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `Color_idColor` int(11) DEFAULT NULL,
  `descuento` double NOT NULL,
  `UnidadMedida_idUnidadMedida` int(11) NOT NULL,
  `Stock` double NOT NULL,
  `StockMinimo` double NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `fk_Producto_Proveedor1_idx` (`Proveedor_idProveedor`),
  KEY `fk_Producto_Color1_idx` (`Color_idColor`),
  KEY `fk_Producto_UnidadMedida1_idx` (`UnidadMedida_idUnidadMedida`),
  CONSTRAINT `fk_Producto_Color1` FOREIGN KEY (`Color_idColor`) REFERENCES `Color` (`idColor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Producto_Proveedor1` FOREIGN KEY (`Proveedor_idProveedor`) REFERENCES `Proveedor` (`idProveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Producto_UnidadMedida1` FOREIGN KEY (`UnidadMedida_idUnidadMedida`) REFERENCES `UnidadMedida` (`idUnidadMedida`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Producto`
--

LOCK TABLES `Producto` WRITE;
/*!40000 ALTER TABLE `Producto` DISABLE KEYS */;
INSERT INTO `Producto` VALUES (1,'bisagra','herrajes',210,1,1,1,0,1,100,30),(2,'riel','cajones',150,1,1,1,0,1,140,40);
/*!40000 ALTER TABLE `Producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Proveedor`
--

DROP TABLE IF EXISTS `Proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Proveedor` (
  `idProveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(60) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `Empresa_ruc` varchar(12) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `Pais_idPais` int(11) NOT NULL,
  PRIMARY KEY (`idProveedor`,`Pais_idPais`),
  KEY `fk_Proveedor_Pais1_idx` (`Pais_idPais`),
  CONSTRAINT `fk_Proveedor_Pais1` FOREIGN KEY (`Pais_idPais`) REFERENCES `Pais` (`idPais`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Proveedor`
--

LOCK TABLES `Proveedor` WRITE;
/*!40000 ALTER TABLE `Proveedor` DISABLE KEYS */;
INSERT INTO `Proveedor` VALUES (1,'Blum','voralberg','2342342','23424234',1,1);
/*!40000 ALTER TABLE `Proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UnidadMedida`
--

DROP TABLE IF EXISTS `UnidadMedida`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UnidadMedida` (
  `idUnidadMedida` int(11) NOT NULL AUTO_INCREMENT,
  `nombreMedida` varchar(45) NOT NULL,
  PRIMARY KEY (`idUnidadMedida`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UnidadMedida`
--

LOCK TABLES `UnidadMedida` WRITE;
/*!40000 ALTER TABLE `UnidadMedida` DISABLE KEYS */;
INSERT INTO `UnidadMedida` VALUES (1,'caja');
/*!40000 ALTER TABLE `UnidadMedida` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Usuario`
--

DROP TABLE IF EXISTS `Usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Usuario` (
  `codigoUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `apellidoPaterno` varchar(60) NOT NULL,
  `apellidoMaterno` varchar(60) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `correo` varchar(45) NOT NULL,
  `dni` varchar(10) NOT NULL,
  `sexo` varchar(15) NOT NULL,
  `fechaRegistro` date NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `username` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `prioridad` tinyint(4) NOT NULL,
  PRIMARY KEY (`codigoUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Usuario`
--

LOCK TABLES `Usuario` WRITE;
/*!40000 ALTER TABLE `Usuario` DISABLE KEYS */;
INSERT INTO `Usuario` VALUES (1,'GONZALES','RODRIGUEZ','FRANK','frankcj7@gmail.com','7053452','Masculino','2018-05-21',1,'admin','123456',1),(2,'ALFARO','RAMOS','JORGE','jorgexD@gmail.com','76984325','Masculino','2018-05-23',0,'JorgexDxDxD','elpro',1),(3,'ASDASDAS','ADASDASD','ASDASDASD','asdasd@pasdpas.com','123131','Masculino','2018-05-23',1,'lol','123',3),(4,'ASDASDAS','ADASDASD','ASDASDASD','asdasd@pasdpas.com','123131','Masculino','2018-05-23',1,'lol','123',3),(5,'Perez','Guzman','Fernando','a20114263@pucp.pe','47881327','Masculino','2018-05-23',1,'ferp93','123',3),(6,'ALFARO','RAMOS','JORGE','jorgealfaro@pucp.edu','45252355','Masculino','2018-05-23',1,'JorgexDxDxD','qwerty',2),(7,'ASDASD','ASDASD','ASDASD','asdasd','asdasd','Femenino','2018-05-23',1,'asdasd','asdasd',3),(8,'ASDASD','ASDASD','ASDASD','asdasd','asdasd','Femenino','2018-05-23',1,'asdasd','asdasd',3),(9,'ASDAS','ASDASD','ASDASD','asdas','asdasd','Femenino','2018-05-23',1,'asdasd','asdasd',3),(10,'ASDASDA','DASDASD','DASDAS','asdasd','asdasd','Femenino','2018-05-23',1,'asdasd','asdasd',3),(11,'ASDAS','ASDASD','ASDASD','asdasd','sdasd','Femenino','2018-05-23',0,'asdas','dasd',3),(12,'REGALADO','BECERRA','JOSE','becerra.j@pucp.edu.pe','98765432','Femenino','2018-05-23',0,'josepucp','asd1q23',3),(13,'','','','','','Femenino','2018-05-23',0,'','',3),(14,'NOMEACUERDO','CASTAÑEDA','LUCAS','lucas@pucp.edupe','1123234234','Femenino','2018-05-23',0,'lucasxd','lucasxd',3),(15,'REG','RUIZ','JUAN','juan@pucp.edu.pe','456456','Femenino','2018-05-23',0,'juan212','soyjuan',3),(16,'ASD','ASD','ASD','asd','1232','Femenino','2018-05-23',0,'asdasd','123',3),(17,'ASDASD','ASDASDASD','ASDASD','asdasdas','asdasd','Femenino','2018-05-23',0,'asdasd','asdasd',3),(18,'ASD','ASD','ASD','asd','asd','Femenino','2018-05-23',0,'asd','asd',3),(19,'QQQ','QQQ','QQQ','qwaasdad','123123','Femenino','2018-05-23',0,'asdasdadasd','12312312',3),(20,'WWW','WWW','WWW','www','www','Femenino','2018-05-23',0,'www','www',3),(21,'CAMPOS','ALARCON','ERNESTO','lolol@pucp.edu.pe','12345515','Femenino','2018-05-24',0,'nobody','nobody',3),(22,'EL PILLO','EL PISAO','JUAN','LOslos@juan.com','12235135','Masculino','2018-05-24',0,'Eljuancho','eljuancho1234',3);
/*!40000 ALTER TABLE `Usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vendedor`
--

DROP TABLE IF EXISTS `Vendedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vendedor` (
  `Usuario_codigoUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `meta` int(11) NOT NULL,
  `eficiencia` double NOT NULL,
  `informacion` varchar(200) DEFAULT NULL,
  `seguro` varchar(45) NOT NULL,
  `domicilio` varchar(45) NOT NULL,
  `telofono` varchar(15) NOT NULL,
  `horasMensuales` int(11) NOT NULL,
  `horasCumplidasMensuales` varchar(45) NOT NULL,
  `Local_idLocal` int(11) NOT NULL,
  PRIMARY KEY (`Usuario_codigoUsuario`),
  KEY `fk_Vendedor_Local1_idx` (`Local_idLocal`),
  CONSTRAINT `fk_Vendedor_Local1` FOREIGN KEY (`Local_idLocal`) REFERENCES `Local` (`idLocal`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Vendedor_Usuario1` FOREIGN KEY (`Usuario_codigoUsuario`) REFERENCES `Usuario` (`codigoUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vendedor`
--

LOCK TABLES `Vendedor` WRITE;
/*!40000 ALTER TABLE `Vendedor` DISABLE KEYS */;
INSERT INTO `Vendedor` VALUES (11,0,0,'','asdasd','','asdasd',0,'0',5),(12,0,0,'estudianteexzxzxxzzxx','si','','956043397',0,'0',5),(13,0,0,'','','','',0,'0',5),(14,0,0,'Estudiante 7to Ciclo','si','','94584958',0,'0',5),(15,0,0,'Vendedor constante de la empresa','si','Pueblo Libre','34737473',0,'0',5),(16,0,0,'asjajksjkasd','si','asd','123123',0,'0',5),(17,0,0,'dasdasdas','asdas','','dasd',0,'0',9),(18,0,0,'asd','asd','','asd',0,'0',5),(19,0,0,'asdasdasd','aasdasd','qqqq','12312312',0,'0',5),(20,0,0,'wwww','www','','www',0,'0',5),(21,0,0,'lalala','lalalala','','2223314',0,'0',5),(22,0,0,'lalalsdals','1231125','Av Baciliscos 125','2121512',0,'0',5);
/*!40000 ALTER TABLE `Vendedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Venta`
--

DROP TABLE IF EXISTS `Venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Venta` (
  `idVenta` int(11) NOT NULL AUTO_INCREMENT,
  `fechaCompra` date NOT NULL,
  `tipoDoc` varchar(8) NOT NULL,
  `subToltal` double NOT NULL,
  `total` double NOT NULL,
  `fechaEntrega` date NOT NULL,
  `direccionDeDespacho` varchar(50) NOT NULL,
  `Cliente_codigoCliente` int(11) NOT NULL,
  `Vendedor_Usuario_codigoUsuario1` int(11) NOT NULL,
  PRIMARY KEY (`idVenta`),
  KEY `fk_Venta_Cliente1_idx` (`Cliente_codigoCliente`),
  KEY `fk_Venta_Vendedor1_idx` (`Vendedor_Usuario_codigoUsuario1`),
  CONSTRAINT `fk_Venta_Cliente1` FOREIGN KEY (`Cliente_codigoCliente`) REFERENCES `Cliente` (`codigoCliente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Venta_Vendedor1` FOREIGN KEY (`Vendedor_Usuario_codigoUsuario1`) REFERENCES `Vendedor` (`Usuario_codigoUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Venta`
--

LOCK TABLES `Venta` WRITE;
/*!40000 ALTER TABLE `Venta` DISABLE KEYS */;
/*!40000 ALTER TABLE `Venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'inf282g4'
--

--
-- Dumping routines for database 'inf282g4'
--
/*!50003 DROP PROCEDURE IF EXISTS `COMPROBAR_USUARIO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `COMPROBAR_USUARIO`(
	IN  _USERNAME VARCHAR(45),
	IN  _PASSWORD VARCHAR(45),
	OUT _ES_CORRECTO BOOLEAN,
    OUT _PRIORIDAD TINYINT(4),
    OUT _NOMBRE VARCHAR(60)
)
BEGIN
	DECLARE COMPROBADO BOOLEAN;
	DECLARE Prior TINYINT(4);
    DECLARE r int;
    DECLARE nomb VARCHAR (60);
    DECLARE eliminado TINYINT (1);
    
	SELECT count(*) INTO r
    FROM Usuario U
    WHERE (BINARY  U.username = _USERNAME ) AND (BINARY U.pass = _PASSWORD );
    
    
    SELECT activo INTO eliminado 
    FROM Usuario U
    WHERE (BINARY  U.username = _USERNAME ) AND (BINARY U.pass = _PASSWORD );
    
    if r = 0 OR eliminado = 0 then 
		set _ES_CORRECTO := FALSE ;
        SET _PRIORIDAD := 0;
    ELSE  
		set _ES_CORRECTO := TRUE ;			
		SELECT U.prioridad INTO Prior
		FROM inf282g4.Usuario U
		WHERE (U.username = _USERNAME) AND (U.pass = _PASSWORD);
		SELECT U.nombre INTO nomb
		FROM inf282g4.Usuario U
		WHERE (U.username = _USERNAME) AND (U.pass = _PASSWORD);
        
        SET _PRIORIDAD := Prior;
        SET _NOMBRE := nomb;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `ELIMINAR_USUARIO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `ELIMINAR_USUARIO`(
	IN _ID_USUARIO INT
)
BEGIN
	UPDATE Usuario
    SET activo = 0
    WHERE _ID_USUARIO = CodigoUsuario;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `FILTRAR_GERENTES` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `FILTRAR_GERENTES`(
	IN _NOMBRE VARCHAR(45),
    IN _AP_PATERNO VARCHAR(45),
    IN _PRIORIDAD TINYINT(4),
    IN _DNI VARCHAR(10)
)
BEGIN
    IF _NOMBRE IS NULL THEN
    SET _NOMBRE := '';
    END IF;
	IF _AP_PATERNO IS NULL THEN
    SET _AP_PATERNO := '';
    END IF;
	IF _DNI IS NULL THEN
    SET _DNI := '';
    END IF;
	IF _PRIORIDAD=0 THEN
		SELECT * FROM Usuario
		WHERE nombre LIKE CONCAT(_NOMBRE,'%') AND apellidoPaterno LIKE CONCAT( _AP_PATERNO ,'%')
		AND dni LIKE CONCAT( _DNI , '%') AND activo =1 AND (PRIORIDAD =1 OR PRIORIDAD =2);
	ELSE
		SELECT * FROM Usuario
		WHERE nombre LIKE CONCAT(_NOMBRE,'%') AND apellidoPaterno LIKE CONCAT( _AP_PATERNO ,'%')
		AND dni LIKE CONCAT( _DNI , '%') AND prioridad = _PRIORIDAD AND activo =1;
	END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_CLIENTES` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_CLIENTES`()
BEGIN
	SELECT * FROM Juridico;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_COLOR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_COLOR`()
BEGIN
	SELECT * FROM Color;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_GERENTES` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_GERENTES`()
BEGIN
	SELECT * FROM Usuario WHERE activo =1 and (prioridad =1 or prioridad =2);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_PAISES` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_PAISES`()
BEGIN
	SELECT * FROM Pais;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_PRODUCTO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_PRODUCTO`()
BEGIN
	SELECT * FROM Producto;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_PROVEEDOR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_PROVEEDOR`()
BEGIN
	SELECT * FROM Proveedor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTAR_VENDEDORES` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTAR_VENDEDORES`()
BEGIN
	SELECT * FROM Vendedor,Usuario WHERE  Usuario.activo=1 and (Vendedor.Usuario_codigoUsuario = Usuario.codigoUsuario);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `LISTA_LOCAL` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `LISTA_LOCAL`()
BEGIN
	select * from Local;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `MODIFICAR_GERENTE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `MODIFICAR_GERENTE`(
	IN _ID_USUARIO INT,
	IN _DNI VARCHAR(10),
    IN _NOMBRE VARCHAR(60),
    IN _APELLIDO_PATERNO VARCHAR(60),
    IN _APELLIDO_MATERNO VARCHAR(60),
    IN _SEXO VARCHAR(15),
    IN _CORREO VARCHAR(45),
    IN _USERNAME VARCHAR(45),
	IN _PASSWORD VARCHAR(45),
    IN _PRIORIDAD TINYINT(4)
)
BEGIN
	UPDATE Usuario
    SET dni=_DNI, nombre=_NOMBRE, apellidoPaterno= _APELLIDO_PATERNO,
    apellidoMaterno = _APELLIDO_MATERNO, sexo=_SEXO, correo=_CORREO, username=_USERNAME,
    pass= _PASSWORD, prioridad = _PRIORIDAD
    WHERE _ID_USUARIO = CodigoUsuario;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_COLOR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_COLOR`(
	_NOMBRE VARCHAR(15)
)
BEGIN
	DECLARE _ID INT;
	SET _ID = last_insert_id();
	INSERT INTO Color (idColor, nombreColor)
    VALUES (_ID, _NOMBRE);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_COMPONENTE_KIT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_COMPONENTE_KIT`(
	_CANTIDAD INT(11),
    _KIT_PRODUCTO_CODIGO INT(11),
	_PRODUCTO_CODIGO INT(11)
)
BEGIN
		INSERT INTO ComponenteKit (cantidad, Kit_Producto_codigo, Producto_codigo) VALUES (_CANTIDAD, _KIT_PRODUCTO_CODIGO, _PRODUCTO_CODIGO);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_DETALLE_VENTA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_DETALLE_VENTA`(
	_ID_VENTA INT(11),
    _CODIGO_PRODUCTO INT(11),
    _CANTIDAD DOUBLE,
    _VENTA_VENDEDOR_USUARIO_CODIGOUSUARIO INT(11)
)
BEGIN
	INSERT INTO DetalleVenta (Venta_idVenta, Producto_codigo, cantidad, Venta_Vendedor_Usuario_codigoUsuario) 
    VALUES (_ID_VENTA, _CODIGO_PRODUCTO, _CANTIDAD, _VENTA_VENDEDOR_USUARIO_CODIGOUSUARIO);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_GERENTE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_GERENTE`(
	OUT _ID_USUARIO INT,
	IN _DNI VARCHAR(10),
    IN _NOMBRES VARCHAR(60),
    IN _APELLIDO_PATERNO VARCHAR(60),
    IN _APELLIDO_MATERNO VARCHAR(60),
    IN _SEXO VARCHAR(15),
    IN _CORREO VARCHAR(45),
    IN _USERNAME VARCHAR(45),
	IN _PASSWORD VARCHAR(45),
    IN _PRIORIDAD TINYINT(4)
)
BEGIN
	INSERT INTO Usuario(dni,nombre,apellidoPaterno,apellidoMaterno,sexo,correo,username,pass,prioridad,activo,fechaRegistro)
	VALUES (_DNI,_NOMBRES,_APELLIDO_PATERNO,_APELLIDO_MATERNO,_SEXO,_CORREO,_USERNAME,_PASSWORD,_PRIORIDAD,1,CURDATE());
	SET _ID_USUARIO = @@last_insert_id;
	INSERT INTO Gerente(Usuario_CodigoUsuario) VALUES (_ID_USUARIO);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_KIT` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_KIT`(
	_CODIGO INT(11),
    _NOMBRE VARCHAR(200),
    _FAMILIA VARCHAR(80),
    _PRECIO DOUBLE,
    _PROVEEDOR INT,
    _ACTIVO TINYINT,
    _COLOR_IDCOLOR INT,
    _DESCUENTO DOUBLE,
    _UNIDADMEDIDA INT
)
BEGIN
	INSERT INTO PRODUCTO (codigo, nombre, familia, precio, Proveedor_idProveedor, activo, Color_idColor, descuento, UnidadMedida_idUnidadMedida)
    VALUES (_CODIGO, _NOMBRE, _FAMILIA, _PRECIO, _PROVEEDOR, _ACTIVO, _COLOR_IDCOLOR, _DESCUENTO, _UNIDADMEDIDA);
    INSERT INTO KIT (Producto_codigo) VALUES (codigo);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_PRODUCTO` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_PRODUCTO`(
	_CODIGO INT(11),
    _NOMBRE VARCHAR(200),
    _FAMILIA VARCHAR(80),
    _PRECIO DOUBLE,
    _PROVEEDOR INT,
    _ACTIVO TINYINT,
    _COLOR_IDCOLOR INT,
    _DESCUENTO DOUBLE,
    _UNIDADMEDIDA INT,
    _STOCK INT,
    _STOCK_MINIMO INT
)
BEGIN
	INSERT INTO PRODUCTO (codigo, nombre, familia, precio, Proveedor_idProveedor, activo, Color_idColor, descuento, UnidadMedida_idUnidadMedida, Stock, StockMinimo)
    VALUES (_CODIGO, _NOMBRE, _FAMILIA, _PRECIO, _PROVEEDOR, _ACTIVO, _COLOR_IDCOLOR, _DESCUENTO, _UNIDADMEDIDA, _STOCK, _STOCK_MINIMO);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_PROVEEDOR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_PROVEEDOR`(
	_NOMBRE VARCHAR(15)
)
BEGIN
	DECLARE _ID INT;
	SET _ID = last_insert_id();
	INSERT INTO Color (idColor, nombreColor)
    VALUES (_ID, _NOMBRE);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_VENDEDOR` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_VENDEDOR`(
	OUT _ID_USUARIO INT(11),
	IN _DNI VARCHAR(10),
    IN _NOMBRES VARCHAR(60),
    IN _APELLIDO_PATERNO VARCHAR(60),
    IN _APELLIDO_MATERNO VARCHAR(60),
    IN _SEXO VARCHAR(15),
    IN _CORREO VARCHAR(45),
    IN _USERNAME VARCHAR(45),
	IN _PASSWORD VARCHAR(45),
    IN _PRIORIDAD TINYINT(4),
    IN _META INT(11),
    IN _EFICIENCIA DOUBLE,
    IN _INFORMACION VARCHAR(45),
    IN _SEGURO VARCHAR(45),
    IN _DOMICILIO VARCHAR(45),
    IN _TELEFONO VARCHAR(15),
    IN _LOCAL_ID INT(11)
)
BEGIN
	INSERT INTO Usuario(dni,nombre,apellidoPaterno,apellidoMaterno,sexo,correo,username,pass,prioridad,activo,fechaRegistro)
	VALUES (_DNI,_NOMBRES,_APELLIDO_PATERNO,_APELLIDO_MATERNO,_SEXO,_CORREO,_USERNAME,_PASSWORD,3,1,CURDATE());
	SET _ID_USUARIO = @@last_insert_id;
	INSERT INTO Vendedor(Usuario_CodigoUsuario,
    meta,eficiencia,informacion,seguro,domicilio,telofono,horasMensuales,horasCumplidasMensuales,Local_idLocal) 
			VALUES (_ID_USUARIO,0,0.0,_INFORMACION,_SEGURO,_DOMICILIO,_TELEFONO,0,0,_LOCAL_ID);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `REGISTRAR_VENTA` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`inf282g4`@`%` PROCEDURE `REGISTRAR_VENTA`(
    _TIPODOC VARCHAR(8),
    _SUBTOTAL DOUBLE,
    _TOTAL DOUBLE,
    _FECHA_ENTREGA DATETIME,
    _DIRECCION_DE_DESPACHO VARCHAR(50),
    _CODIGO_CLIENTE INT(11),
    _CODIGO_VENDEDOR INT(11)
)
BEGIN
	DECLARE _ID INT;
	SET _ID = last_insert_id();
	INSERT INTO VENTA(idVenta, fechaCompra, tipoDoc, subTotal, total, fechaEntrega, direccionDeDespacho, Cliente_codigoCliente, Vendedor_Usuario_codigoUsuario1) 
    VALUES(_ID, NOW(),_FECHA, _TIPODOC, _SUBTOTAL, _TOTAL, _FECHA_ENTREGA , _DIRECCION_DE_DESPACHO , _CODIGO_CLIENTE , _CODIGO_VENDEDOR);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-24  0:15:47
