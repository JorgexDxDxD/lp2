package Modelo;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;

public class Exhibicion extends Local{

    public ArrayList<DetalleProd> getDetalles() {
        return detalles;
    }

    public void setDetalles(ArrayList<DetalleProd> detalles) {
        this.detalles = detalles;
    }
    private Date FechaIniContrato;
    private DiaSemana _diaIni;
    private DiaSemana _diaFin;
    private byte _activo;
    private Cliente _cliente_codigoCliente; 
    private ArrayList<DetalleProd> detalles;
    
    public Exhibicion(){
        detalles = new ArrayList<>();
    }

    public DiaSemana getDiaIni() {
        return _diaIni;
    }

    public void setDiaIni(DiaSemana _diaIni) {
        this._diaIni = _diaIni;
    }

    public DiaSemana getDiaFin() {
        return _diaFin;
    }

    public void setDiaFin(DiaSemana _diaFin) {
        this._diaFin = _diaFin;
    }

    public byte getActivo() {
        return _activo;
    }

    public void setActivo(byte _activo) {
        this._activo = _activo;
    }

    public Cliente getCliente_codigoCliente() {
        return _cliente_codigoCliente;
    }

    public void setCliente_codigoCliente(Cliente _cliente_codigoCliente) {
        this._cliente_codigoCliente = _cliente_codigoCliente;
    }
    
    public void devolverProducto(Producto p, double cant){
    }

    public void devolverAlmacen(ArrayList<Producto> listP, ArrayList<Double> listC){
    }	

    public Date getFechaIniContrato() {
        return FechaIniContrato;
    }

    public void setFechaIniContrato(Date FechaIniContrato) {
        this.FechaIniContrato = FechaIniContrato;
    }
}