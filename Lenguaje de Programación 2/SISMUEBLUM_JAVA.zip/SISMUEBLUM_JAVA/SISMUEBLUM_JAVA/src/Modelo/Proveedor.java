package Modelo;

import java.util.ArrayList;

public class Proveedor {
    private int _idProveedor;
    private String _nombre;
    private String _direccion;
    private String _telefono;
    private String _empresa_ruc;
    private boolean _activo;
    private Pais _pais_idPais;
    private ArrayList<Producto> _producto;
    
    public Proveedor (){
        _producto = new ArrayList<>();
    }

    public int getIdProveedor() {
        return _idProveedor;
    }

    public void setIdProveedor(int _idProveedor) {
        this._idProveedor = _idProveedor;
    }

    public String getNombre() {
        return _nombre;
    }

    public void setNombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String getDireccion() {
        return _direccion;
    }

    public void setDireccion(String _direccion) {
        this._direccion = _direccion;
    }

    public String getTelefono() {
        return _telefono;
    }

    public void setTelefono(String _telefono) {
        this._telefono = _telefono;
    }

    public String getEmpresa_ruc() {
        return _empresa_ruc;
    }

    public void setEmpresa_ruc(String _empresa_ruc) {
        this._empresa_ruc = _empresa_ruc;
    }

    public boolean getActivo() {
        return _activo;
    }

    public void setActivo(boolean _activo) {
        this._activo = _activo;
    }

    public Pais getPais_idPais() {
        return _pais_idPais;
    }

    public void setPais_idPais(Pais _pais_idPais) {
        this._pais_idPais = _pais_idPais;
    }

    public ArrayList<Producto> getProducto() {
        return _producto;
    }

    public void setProducto(ArrayList<Producto> _producto) {
        this._producto = _producto;
    }
    
}