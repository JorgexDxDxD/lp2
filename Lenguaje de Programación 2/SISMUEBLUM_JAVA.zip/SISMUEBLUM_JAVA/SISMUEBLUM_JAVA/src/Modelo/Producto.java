package Modelo;

public class Producto {

    
    private int _codigo;
    private String _nombre;
    private String _familia;
    private double _precio;
    private boolean _activo;
    private double _descuento;
    private UnidadMedida _medida; //vacio para kit
    private Proveedor _proveedor_idProveedor;
    private Color _color_idColor; //vacio para kit
    private Kit _kit; 
    private double _stock;
    private double _stockM;
    private String _proveedor;
    private String _color;
    private String _unidad;
    
    //para saber en dónde se encuentra cada producto, estos ArrayListes
    /*
    private ArrayList<ComponenteKit> _componenteKit = new ArrayList<ComponenteKit>();
    private ArrayList<DetalleProd> _detalleProd = new ArrayList<DetalleProd>();
    private ArrayList<DetalleVenta> _detalleVenta = new ArrayList<DetalleVenta>();
    */
    

    public String getProveedor() {
        return _proveedor;
    }


    public void setProveedor(String _proveedor) {
        this._proveedor = _proveedor;
    }


    public String getColor() {
        return _color;
    }


    public void setColor(String _color) {
        this._color = _color;
    }

    public String getUnidad() {
        return _unidad;
    }

    public void setUnidad(String _unidad) {
        this._unidad = _unidad;
    }
    
    
    public Producto(){}
    
    public double getStock(){
        return _stock;
    }
    
    public void setStock(double _stock){
        this._stock = _stock;
    }
    
    public int getCodigo() {
        return _codigo;
    }

    public void setCodigo(int _codigo) {
        this._codigo = _codigo;
    }

    public String getNombre() {
        return _nombre;
    }

    public void setNombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String getFamilia() {
        return _familia;
    }

    public void setFamilia(String _familia) {
        this._familia = _familia;
    }

    public double getPrecio() {
        return _precio;
    }

    public void setPrecio(double _precio) {
        this._precio = _precio;
    }

    public boolean getActivo() {
        return _activo;
    }

    public void setActivo(boolean _activo) {
        this._activo = _activo;
    }

    public double getDescuento() {
        return _descuento;
    }

    public void setDescuento(double _descuento) {
        this._descuento = _descuento;
    }

    public UnidadMedida getMedida() {
        return _medida;
    }

    public void setMedida(UnidadMedida _medida) {
        this._medida = _medida;
    }

    public Proveedor getProveedor_idProveedor() {
        return _proveedor_idProveedor;
    }

    public void setProveedor_idProveedor(Proveedor _proveedor_idProveedor) {
        this._proveedor_idProveedor = _proveedor_idProveedor;
    }

    public Color getColor_idColor() {
        return _color_idColor;
    }

    public void setColor_idColor(Color _color_idColor) {
        this._color_idColor = _color_idColor;
    }

    public Kit getKit() {
        return _kit;
    }

    public void setKit(Kit _kit) {
        this._kit = _kit;
    }
/*
    public ArrayList<ComponenteKit> getComponenteKit() {
        return _componenteKit;
    }

    public void setComponenteKit(ArrayList<ComponenteKit> _componenteKit) {
        this._componenteKit = _componenteKit;
    }

    public ArrayList<DetalleProd> getDetalleProd() {
        return _detalleProd;
    }

    public void setDetalleProd(ArrayList<DetalleProd> _detalleProd) {
        this._detalleProd = _detalleProd;
    }

    public ArrayList<DetalleVenta> getDetalleVenta() {
        return _detalleVenta;
    }

    public void setDetalleVenta(ArrayList<DetalleVenta> _detalleVenta) {
        this._detalleVenta = _detalleVenta;
    }
*/
}