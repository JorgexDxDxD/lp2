package Modelo;

public class DetalleVenta {
	private double _cantidad;
	private Producto _producto_codigo;

    public double getCantidad() {
        return _cantidad;
    }

    public void setCantidad(double _cantidad) {
        this._cantidad = _cantidad;
    }

    public Producto getProducto_codigo() {
        return _producto_codigo;
    }

    public void setProducto_codigo(Producto _producto_codigo) {
        this._producto_codigo = _producto_codigo;
    }
}