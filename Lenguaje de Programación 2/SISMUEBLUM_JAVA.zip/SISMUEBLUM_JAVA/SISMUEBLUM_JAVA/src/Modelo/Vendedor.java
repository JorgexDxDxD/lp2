package Modelo;

import java.util.ArrayList;
import java.util.Date;

public class Vendedor  extends Usuario implements IConsultable{
    private double _meta;
    private double _eficiencia;
    private String _informacion;
    private String _seguro;
    private String _domicilio;
    private String _telofono;
    private int _horasMensuales;
    private String _horasCumplidasMensuales;
    private Local _local_idLocal;
    private ArrayList<Venta> _venta = new ArrayList<Venta>();
    private Double monto_acumulado;
    public Vendedor(String nombre, String apellidoPaterno,String apellidoMaterno,
            String dni, String username,String password, Date fecha,
            int codigo, String email, String sexo, String seguro,String domicilio,
            String informacion) {
        super(nombre,apellidoPaterno,apellidoMaterno,dni,username,password,3,
                fecha,codigo,email,sexo);
        this._domicilio = domicilio;
        this._informacion = informacion;
        this._seguro=seguro;
        
        
        //FALTA ARREGLAR CONSTRUCTOR!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    }
        
    public void setMontoAsignado(Double monto){
        this.monto_acumulado = monto;
    }
    public Double getMontoAcumulado(){
        return this.monto_acumulado;
    }
    public Vendedor(int codigo){
        super(codigo);
    }
    
    public String consultarDatos()
    {
        return "";
    }

    public void registrarCliente()
    {

    }

    public void registrarVenta(Venta v, Cliente cli){

    }

    public void buscarCliente(String dniCli){

    }

    public void consultarCliente(Cliente cli){

    }

    public void registrarExhibicion(){

    }

    public void comprobarStock(Producto p){

    }

    public void emitirCotizacion(){

    }

    public double getMeta() {
        return _meta;
    }

    public void setMeta(double _meta) {
        this._meta = _meta;
    }

    public double getEficiencia() {
        return _eficiencia;
    }

    public void setEficiencia(double _eficiencia) {
        this._eficiencia = _eficiencia;
    }

    public String getInformacion() {
        return _informacion;
    }

    public void setInformacion(String _informacion) {
        this._informacion = _informacion;
    }

    public String getSeguro() {
        return _seguro;
    }

    public void setSeguro(String _seguro) {
        this._seguro = _seguro;
    }

    public String getDomicilio() {
        return _domicilio;
    }

    public void setDomicilio(String _domicilio) {
        this._domicilio = _domicilio;
    }

    public String getTelofono() {
        return _telofono;
    }

    public void setTelofono(String _telofono) {
        this._telofono = _telofono;
    }

    public int getHorasMensuales() {
        return _horasMensuales;
    }

    public void setHorasMensuales(int _horasMensuales) {
        this._horasMensuales = _horasMensuales;
    }

    public String getHorasCumplidasMensuales() {
        return _horasCumplidasMensuales;
    }

    public void setHorasCumplidasMensuales(String _horasCumplidasMensuales) {
        this._horasCumplidasMensuales = _horasCumplidasMensuales;
    }

    public Local getLocal_idLocal() {
        return _local_idLocal;
    }

    public void setLocal_idLocal(Local _local_idLocal) {
        this._local_idLocal = _local_idLocal;
    }

    public ArrayList<Venta> getVenta() {
        return _venta;
    }

    public void setVenta(ArrayList<Venta> _venta) {
        this._venta = _venta;
    }
}