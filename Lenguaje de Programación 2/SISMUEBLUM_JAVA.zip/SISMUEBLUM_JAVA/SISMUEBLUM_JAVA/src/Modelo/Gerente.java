package Modelo;

import java.util.ArrayList;
import java.util.Date;

public class Gerente extends Usuario implements IConsultable {

    public Gerente(String nombre, String apellidoPaterno,String apellidoMaterno,
            String dni, String username,String password,int prioridad, Date fecha,
            int codigo, String email, String sexo) {
        super(nombre,apellidoPaterno,apellidoMaterno,dni,username,password,prioridad,
                fecha,codigo,email,sexo);
        
        
        
    }
//	public Usuario _usuario_codigoUsuario;
    public void consultarVendedoresSede(String sede)
    {

    }

    public void asignarVendedorSede(String dniVend,String sede)
    {

    }

    public void moverReasignarCliente(String dniVend, String dniCli)
    {

    }

    public void emitirReporteVendedor(String dniVend)
    {

    }

    public void registrarVendedor(String nombre, String apellidoPaterno, String apellidoMaterno, 
            String dni, String username, String password,
            String sexo, String seguro, String domicilio, String informacion)
    {
            Vendedor v;
//		v = new Vendedor(nombre, apellidoPaterno, apellidoMaterno, dni, username, password,
//			sexo,  seguro, domicilio, informacion);
    }

    public void modificarVendedor(String dniVend){

    }

    public void eliminarVendedor(String dniVend)
    {

    }
    public void revisarCliente(String dni)
    {

    }

    public String consultarDatos()
    {
            return "";
    }

    public void aumentarStock(Producto p, int cantidad){

    }

    public void registrarKits(ArrayList<Producto> listaProductos){

    }

    public void modificarKits(Kit k){

    }

    public void eliminarKits(Kit k){

    }

    public void registrarProductos(Producto p){

    }

    public void modificarProductos(Producto p){

    }

    public void eliminarProductos(Producto p){

    }
}