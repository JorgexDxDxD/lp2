package Modelo;

public class Color {

    public int getIdColor() {
        return _idColor;
    }

    public void setIdColor(int _idColor) {
        this._idColor = _idColor;
    }

    public String getNombreColor() {
        return _nombreColor;
    }

    public void setNombreColor(String _nombreColor) {
        this._nombreColor = _nombreColor;
    }
    private int _idColor;
    private String _nombreColor;
}