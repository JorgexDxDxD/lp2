package Modelo;

import java.util.ArrayList;

public class Almacen extends Local{
    private int _empresa_ruc;

    public Almacen(){
    }
    public void mostrarAlmacen(){
    }

    public void registrarProducto(Producto p, int cant){
    }

    public void sacarProductos(Producto p, int cant){
    }

    public void enviarAExhibicion(ArrayList<DetalleProd> p){
    }
    
    public int getEmpresa_ruc() {
        return _empresa_ruc;
    }

    public void setEmpresa_ruc(int _empresa_ruc) {
        this._empresa_ruc = _empresa_ruc;
    }

}