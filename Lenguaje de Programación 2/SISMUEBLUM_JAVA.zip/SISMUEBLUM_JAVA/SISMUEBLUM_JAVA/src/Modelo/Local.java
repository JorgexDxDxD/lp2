package Modelo;

import java.util.ArrayList;

public class Local {
    private int _idLocal;
    private String _direccion;
    private String _telefono;
    private Almacen _almacen;
    private ArrayList<Vendedor> _vendedor;
    private ArrayList<Producto> listProductos;
    private ArrayList<Double> listCantidad;
    
    public Local(){ 
        _vendedor= new ArrayList<>();
        listProductos=new ArrayList<>();
        listCantidad=new ArrayList<>();
    }
    
    public void mostrarProductos(){
        
    }
    public void agregarProducto(Producto p, double cant){
    }

    public void agregarVendedor(Vendedor v){
        _vendedor.add(v);
    }

    public String consultarVendedores(){
        return "";
    }
    
    public int getIdLocal() {
        return _idLocal;
    }

    public void setIdLocal(int _idLocal) {
        this._idLocal = _idLocal;
    }

    public String getDireccion() {
        return _direccion;
    }

    public void setDireccion(String _direccion) {
        this._direccion = _direccion;
    }

    public String getTelefono() {
        return _telefono;
    }

    public void setTelefono(String _telefono) {
        this._telefono = _telefono;
    }

    public Almacen getAlmacen() {
        return _almacen;
    }

    public void setAlmacen(Almacen _almacen) {
        this._almacen = _almacen;
    }

    public ArrayList<Vendedor> getVendedor() {
        return _vendedor;
    }

    public void setVendedor(ArrayList<Vendedor> _vendedor) {
        this._vendedor = _vendedor;
    }

    public ArrayList<Producto> getListProductos() {
        return listProductos;
    }

    public void setListProductos(ArrayList<Producto> listProductos) {
        this.listProductos = listProductos;
    }

    public ArrayList<Double> getListCantidad() {
        return listCantidad;
    }

    public void setListCantidad(ArrayList<Double> listCantidad) {
        this.listCantidad = listCantidad;
    }

    @Override
    public String toString() {
        return _idLocal +" - "+ _direccion;
    }
}