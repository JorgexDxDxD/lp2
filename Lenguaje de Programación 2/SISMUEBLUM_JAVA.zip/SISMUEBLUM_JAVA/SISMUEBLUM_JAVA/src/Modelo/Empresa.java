package Modelo;

public class Empresa {
	private String _ruc;
	private String _direccionPrinc;

    public String getRuc() {
        return _ruc;
    }

    public void setRuc(String _ruc) {
        this._ruc = _ruc;
    }

    public String getDireccionPrinc() {
        return _direccionPrinc;
    }

    public void setDireccionPrinc(String _direccionPrinc) {
        this._direccionPrinc = _direccionPrinc;
    }
}