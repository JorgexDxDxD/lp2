package Modelo;

import java.util.Date;

public abstract class Usuario {
    private int _codigoUsuario;
    private String _apellidoPaterno;
    private String _apellidoMaterno;
    private String _nombre;
    private String _correo;
    private String _dni;
    private String _sexo;
    private Date _fechaRegistro;
    private boolean _activo;
    private String _username;
    private String _password;
    private int _prioridad;
    
    public Usuario(String nombre, String apellidoPaterno,String apellidoMaterno,
            String dni, String username,String password,int prioridad, Date fecha,
            int codigo, String email, String sexo){
        this._nombre = nombre;
        this._apellidoPaterno = apellidoPaterno;
        this._apellidoMaterno = apellidoMaterno;
        this._activo = true;
        this._dni = dni;
        this._codigoUsuario = codigo;
        this._correo = email;
        this._fechaRegistro = fecha;
        this._password = password;
        this._prioridad = prioridad;
        this._sexo = sexo;
        this._username = username;
    }
    
    public Usuario(int codigo){
        this._codigoUsuario = codigo;
    }
    
    public int getCodigoUsuario() {
        return _codigoUsuario;
    }

    public void setCodigoUsuario(int _codigoUsuario) {
        this._codigoUsuario = _codigoUsuario;
    }

    public String getApellidoPaterno() {
        return _apellidoPaterno;
    }

    public void setApellidoPaterno(String _apellidoPaterno) {
        this._apellidoPaterno = _apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return _apellidoMaterno;
    }

    public void setApellidoMaterno(String _apellidoMaterno) {
        this._apellidoMaterno = _apellidoMaterno;
    }

    public String getNombre() {
        return _nombre;
    }

    public void setNombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String getCorreo() {
        return _correo;
    }

    public void setCorreo(String _correo) {
        this._correo = _correo;
    }

    public String getDni() {
        return _dni;
    }

    public void setDni(String _dni) {
        this._dni = _dni;
    }

    public String getSexo() {
        return _sexo;
    }

    public void setSexo(String _sexo) {
        this._sexo = _sexo;
    }

    public Date getFechaRegistro() {
        return _fechaRegistro;
    }

    public void setFechaRegistro(Date _fechaRegistro) {
        this._fechaRegistro = _fechaRegistro;
    }

    public boolean getActivo() {
        return _activo;
    }

    public void setActivo(boolean _activo) {
        this._activo = _activo;
    }

    public String getUsername() {
        return _username;
    }

    public void setUsername(String _username) {
        this._username = _username;
    }

    public String getPassword() {
        return _password;
    }

    public void setPassword(String _password) {
        this._password = _password;
    }

    public int getPrioridad() {
        return _prioridad;
    }

    public void setPrioridad(int _prioridad) {
        this._prioridad = _prioridad;
    }
}