package Modelo;
public enum DiaSemana{
	Lunes, Martes, Miercoles, Jueves, Viernes, Sabado, Domingo
}