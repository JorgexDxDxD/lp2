package Modelo;

import java.util.Date;
import java.util.ArrayList;

public abstract class Cliente {
    private int _codigoCliente;
    private String _telefono;
    private String _correo;
    private String _direccion;
    private Date _fechaDeRegistro;
    private boolean _activo;
    private ArrayList<Venta> _venta;
    private ArrayList<Exhibicion> _exhibicion;    
    private Vendedor vendedor;
    public int getCodigoCliente() {
        return _codigoCliente;
    }

    public void setCodigoCliente(int _codigoCliente) {
        this._codigoCliente = _codigoCliente;
    }

    public String getTelefono() {
        return _telefono;
    }

    public void setTelefono(String _telefono) {
        this._telefono = _telefono;
    }

    public String getCorreo() {
        return _correo;
    }

    public void setCorreo(String _correo) {
        this._correo = _correo;
    }

    public String getDireccion() {
        return _direccion;
    }

    public void setDireccion(String _direccion) {
        this._direccion = _direccion;
    }

    public Date getFechaDeRegistro() {
        return _fechaDeRegistro;
    }

    public void setFechaDeRegistro(Date _fechaDeRegistro) {
        this._fechaDeRegistro = _fechaDeRegistro;
    }

    public boolean getActivo() {
        return _activo;
    }

    public void setActivo(boolean _activo) {
        this._activo = _activo;
    }

    public ArrayList<Venta> getVenta() {
        return _venta;
    }

    public void setVenta(ArrayList<Venta> _venta) {
        this._venta = _venta;
    }

    public ArrayList<Exhibicion> getExhibicion() {
        return _exhibicion;
    }

    public void setExhibicion(ArrayList<Exhibicion> _exhibicion) {
        this._exhibicion = _exhibicion;
    }
    
    public Vendedor getVendedor(){
        return vendedor;
    }
    
    public void SetVendedor(Vendedor _vendedor){
        this.vendedor = _vendedor;
    }
    
    public Cliente(int cod, String telefono, String correo, String direccion) { 
        this.setCodigoCliente(cod);
        this.setDireccion(direccion);
        this.setTelefono(telefono);
        this.setCorreo(correo);
        _venta = new ArrayList<>();
        _exhibicion= new ArrayList<>();
    }
    
    public Cliente(int cod, String telefono, String correo, String direccion, Vendedor v) { 
        this.setCodigoCliente(cod);
        this.setDireccion(direccion);
        this.setTelefono(telefono);
        this.setCorreo(correo);
        this.SetVendedor(v);
        _venta = new ArrayList<>();
        _exhibicion= new ArrayList<>();
    }
    
    public Cliente() { 
        _venta = new ArrayList<>();
        _exhibicion= new ArrayList<>();
    }
    
    public void registrarVenta(Venta v)
    {

    }
        
}