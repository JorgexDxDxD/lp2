package Modelo;

import java.util.ArrayList;

public class Kit extends Producto {
//	public Producto _producto_codigo;
    private ArrayList<ComponenteKit> _componenteKit;
    
    public Kit(){
        _componenteKit = new ArrayList<>();
    }

    public void anhadirComponente(Producto producto, double cantidad){
        ComponenteKit componente = new ComponenteKit();
        //
        getComponenteKit().add(componente);
    }

    /**
     * @return the _componenteKit
     */
    public ArrayList<ComponenteKit> getComponenteKit() {
        return _componenteKit;
    }

    /**
     * @param _componenteKit the _componenteKit to set
     */
    public void setComponenteKit(ArrayList<ComponenteKit> _componenteKit) {
        this._componenteKit = _componenteKit;
    }
}