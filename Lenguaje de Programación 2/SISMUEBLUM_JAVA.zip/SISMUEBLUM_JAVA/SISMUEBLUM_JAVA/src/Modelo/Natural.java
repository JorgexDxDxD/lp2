package Modelo;

public class Natural extends Cliente implements IConsultable{
	private String _nombre;
	private String _apellidoPaterno;
	private String _apellidoMaterno;
	private String _dni;

    public Natural(String nombre, String apPat,String apMat, String dni, 
        String telefono, String correo, String direccion) {
        this.setNombre(nombre);
        this.setApellidoPaterno(apPat);
        this.setApellidoMaterno(apMat);
        this.setDireccion(direccion);
        this.setDni(dni);
        this.setCorreo(correo);
        this.setTelefono(telefono);
    }
    
    public Natural(String nombre, String apPat,String apMat, String dni, 
        int cod, String telefono, String correo, String direccion) {
        super(cod,telefono, correo, direccion);
        this.setNombre(nombre);
        this.setApellidoPaterno(apPat);
        this.setApellidoMaterno(apMat);
        this.setDni(dni);
    }

    public Natural(String nombre, String apPat,String apMat, String dni, 
        int cod, String telefono, String correo, String direccion, Vendedor v) {
        super(cod,telefono, correo, direccion,v);
        this.setNombre(nombre);
        this.setApellidoPaterno(apPat);
        this.setApellidoMaterno(apMat);
        this.setDni(dni);
    }
        
    public Natural() {
    }

    public String getNombre() {
        return _nombre;
    }

    public void setNombre(String _nombre) {
        this._nombre = _nombre;
    }

    public String getApellidoPaterno() {
        return _apellidoPaterno;
    }

    public void setApellidoPaterno(String _apellidoPaterno) {
        this._apellidoPaterno = _apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return _apellidoMaterno;
    }

    public void setApellidoMaterno(String _apellidoMaterno) {
        this._apellidoMaterno = _apellidoMaterno;
    }

    public String getDni() {
        return _dni;
    }

    public void setDni(String _dni) {
        this._dni = _dni;
    }
    public String consultarDatos(){
        return "";
    }
}