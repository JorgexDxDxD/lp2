package Modelo;

import java.util.ArrayList;

public class Pais {
    private int _idPais;
    private String _nombrePais;
    private ArrayList<Proveedor> _proveedor;

    public Pais(){
        _proveedor  = new ArrayList<>();
    }

    public int getIdPais() {
        return _idPais;
    }

    public void setIdPais(int _idPais) {
        this._idPais = _idPais;
    }

    public String getNombrePais() {
        return _nombrePais;
    }

    public void setNombrePais(String _nombrePais) {
        this._nombrePais = _nombrePais;
    }

    public ArrayList<Proveedor> getProveedor() {
        return _proveedor;
    }

    public void setProveedor(ArrayList<Proveedor> _proveedor) {
        this._proveedor = _proveedor;
    }
}