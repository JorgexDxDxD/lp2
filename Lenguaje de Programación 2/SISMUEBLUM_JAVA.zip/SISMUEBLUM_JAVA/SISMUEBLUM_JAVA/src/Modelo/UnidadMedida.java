/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author jorge
 */
public class UnidadMedida {
    private int _idMedida;
    private Producto producto;
    private String _descripcionMedida;

    public int getIdMedida() {
        return _idMedida;
    }

    public void setIdMedida(int _idMedida) {
        this._idMedida = _idMedida;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getDescripcionMedida() {
        return _descripcionMedida;
    }

    public void setDescripcionMedida(String _descripcionMedida) {
        this._descripcionMedida = _descripcionMedida;
    }
}
