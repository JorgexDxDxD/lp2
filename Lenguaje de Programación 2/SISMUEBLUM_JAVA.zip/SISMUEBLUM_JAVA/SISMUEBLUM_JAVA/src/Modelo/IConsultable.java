package Modelo;

public interface IConsultable {
	String consultarDatos();
}

