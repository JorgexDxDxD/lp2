/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author ferp93
 */
public class Notificacion {

    private TipoNotificacion tipo;
    private String mensaje;
    private int id;
    
    public Notificacion(){}
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    
    /**
     * @return the tipo
     */
    public TipoNotificacion getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(TipoNotificacion tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the mensaje
     */
    public String getMensaje() {
        return mensaje;
    }

    /**
     * @param mensaje the mensaje to set
     */
    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    public void redactarMensajeVendedor(int id,String nombreVendedor,double meta,double montoAcumulado){
        this.setTipo(TipoNotificacion.Vendedor);
        this.setId(id);
        if(meta==montoAcumulado)
            this.setMensaje(nombreVendedor + ", Ha logrado llegar a la meta: " + meta);
        else
            this.setMensaje(nombreVendedor + ", Ha superado la meta: " + meta +"($) con:" + montoAcumulado+"($)");
            
    }
    public void redactarMensajeDeStock(int id, String producto, String proveedor){
        this.setTipo(TipoNotificacion.Stock);
        this.setId(id);
        this.setMensaje(producto +" (" + proveedor + 
                ") ha llegado a su stock mínimo");
    }
}
