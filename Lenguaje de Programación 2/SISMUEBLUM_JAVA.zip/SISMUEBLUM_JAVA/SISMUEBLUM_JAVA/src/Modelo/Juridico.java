package Modelo;

public class Juridico extends Cliente implements IConsultable {
    private String _ruc;
    private String _razon;
    private String _representante;

    public Juridico(String ruc, String razon, String representante,
            String telefono, String correo, String direccion) {    
        this.setRazon(razon);
        this.setRuc(ruc);
        this.setRepresentante(representante);
        this.setDireccion(direccion);
        this.setCorreo(correo);
        this.setTelefono(telefono);
    }
    
    public Juridico(String ruc, String razon, String representante,
        int cod, String telefono, String correo, String direccion) {
        super(cod,telefono, correo, direccion);
        this.setRazon(razon);
        this.setRuc(ruc);
        this.setRepresentante(representante);
    }
    
    public Juridico(String ruc, String razon, String representante,
        int cod, String telefono, String correo, String direccion, Vendedor v) {
        super(cod,telefono, correo, direccion,v);
        this.setRazon(razon);
        this.setRuc(ruc);
        this.setRepresentante(representante);
    }

    public Juridico() {
    }

    public String getRuc() {
        return _ruc;
    }

    public void setRuc(String _ruc) {
        this._ruc = _ruc;
    }

    public String getRazon() {
        return _razon;
    }

    public void setRazon(String _razon) {
        this._razon = _razon;
    }

    public String getRepresentante() {
        return _representante;
    }

    public void setRepresentante(String _representante) {
        this._representante = _representante;
    }
    
    @Override
    public String consultarDatos()
    {
        return "";
    }
}