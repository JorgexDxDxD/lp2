package Modelo;

import Vista.Venta.auxLineaVenta;
import java.util.Date;
import java.util.ArrayList;

public class Venta {
	private int _idVenta;
	private Date _fechaCompra;
	private TipoDocDeVenta _tipoDoc;
	private double _subToltal;
	private double _total;
	private Date _fechaEntrega;
	private String _direccionDeDespacho;
	private Cliente _cliente_codigoCliente;
	private Vendedor _vendedor_Usuario_codigoUsuario1;
	private ArrayList<DetalleVenta> _detalleVenta;
        private ArrayList<auxLineaVenta> _auxDetalleVenta;
        
    public Venta(){
        _detalleVenta = new ArrayList<DetalleVenta>();
        _auxDetalleVenta = new ArrayList<auxLineaVenta>();
    }
    
    public ArrayList<auxLineaVenta> getAuxDetalleVenta() {
        return _auxDetalleVenta;
    }
    
    public void setAuxDetalleVenta(ArrayList<auxLineaVenta> _auxDetalleVenta) {
        this._auxDetalleVenta = _auxDetalleVenta;
    }

    public int getIdVenta() {
        return _idVenta;
    }

    public void setIdVenta(int _idVenta) {
        this._idVenta = _idVenta;
    }

    public Date getFechaCompra() {
        return _fechaCompra;
    }

    public void setFechaCompra(Date _fechaCompra) {
        this._fechaCompra = _fechaCompra;
    }

    public TipoDocDeVenta getTipoDoc() {
        return _tipoDoc;
    }

    public void setTipoDoc(TipoDocDeVenta _tipoDoc) {
        this._tipoDoc = _tipoDoc;
    }

    public double getSubToltal() {
        return _subToltal;
    }

    public void setSubToltal(double _subToltal) {
        this._subToltal = _subToltal;
    }

    public double getTotal() {
        return _total;
    }

    public void setTotal(double _total) {
        this._total = _total;
    }

    public Date getFechaEntrega() {
        return _fechaEntrega;
    }

    public void setFechaEntrega(Date _fechaEntrega) {
        this._fechaEntrega = _fechaEntrega;
    }

    public String getDireccionDeDespacho() {
        return _direccionDeDespacho;
    }

    public void setDireccionDeDespacho(String _direccionDeDespacho) {
        this._direccionDeDespacho = _direccionDeDespacho;
    }

    public Cliente getCliente_codigoCliente() {
        return _cliente_codigoCliente;
    }

    public void setCliente_codigoCliente(Cliente _cliente_codigoCliente) {
        this._cliente_codigoCliente = _cliente_codigoCliente;
    }

    public Vendedor getVendedor_Usuario_codigoUsuario1() {
        return _vendedor_Usuario_codigoUsuario1;
    }

    public void setVendedor_Usuario_codigoUsuario1(Vendedor _vendedor_Usuario_codigoUsuario1) {
        this._vendedor_Usuario_codigoUsuario1 = _vendedor_Usuario_codigoUsuario1;
    }

    public ArrayList<DetalleVenta> getDetalleVenta() {
        return _detalleVenta;
    }

    public void setDetalleVenta(ArrayList<DetalleVenta> _detalleVenta) {
        this._detalleVenta = _detalleVenta;
    }
}