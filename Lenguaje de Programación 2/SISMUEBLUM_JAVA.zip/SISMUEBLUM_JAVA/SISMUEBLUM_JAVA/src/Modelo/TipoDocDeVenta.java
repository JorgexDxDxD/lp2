package Modelo;
public enum TipoDocDeVenta{Factura, Boleta,Cotizacion}