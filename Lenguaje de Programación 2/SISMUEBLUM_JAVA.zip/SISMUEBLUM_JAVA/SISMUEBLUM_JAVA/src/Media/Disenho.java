/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Media;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.plaf.metal.MetalComboBoxButton;

/**
 *
 * @author alulab14
 */
public class Disenho {
    public Color cNaranja;
    public Disenho(Container ventana){
        //System.out.println("Nueva ventana");
        cNaranja = new Color(255, 103, 31);
        aplicarDisenho(ventana);
        setColorDeFondo(ventana);
    }
    
    public void estilzarBoton(javax.swing.JButton boton){
        boton.setBackground(cNaranja);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
    }
    
    public void estilizarComboBox(JComboBox comboBox){
        
        
    }
    
    public void setColorDeFondo(Container ventana){
        ventana.setBackground(Color.white);
    }
    
    public void estilizarTabla(javax.swing.JTable tabla){
        tabla.setOpaque(true);
        tabla.setFillsViewportHeight(true);
        tabla.setBackground(Color.white);
    }
    public void estilizarCheckbox(javax.swing.JCheckBox checkBox){
    }
    
    public void aplicarDisenho(Container contenedor){
        //System.out.println("INICIO:");
        Component[] comp = contenedor.getComponents();
        for (int i = 0;i<comp.length;i++) {
            //System.out.println(comp[i].getClass().getCanonicalName());
            if (comp[i] instanceof JPanel){
                setColorDeFondo((JPanel) comp[i]);
                aplicarDisenho(((JPanel) comp[i]));
            } else if (comp[i] instanceof JScrollPane) aplicarDisenho(((JScrollPane) comp[i]));
            else if (comp[i] instanceof JViewport) aplicarDisenho(((JViewport) comp[i]));
            else if (comp[i] instanceof JButton) estilzarBoton((JButton) comp[i]);
            else if (comp[i] instanceof JTable) estilizarTabla((JTable) comp[i]);
            else if (comp[i] instanceof JCheckBox) estilizarCheckbox((JCheckBox) comp[i]);
            else if (comp[i] instanceof JComboBox) estilizarComboBox((JComboBox) comp[i]);
        }
        //System.out.println("FIN");
    }
}
