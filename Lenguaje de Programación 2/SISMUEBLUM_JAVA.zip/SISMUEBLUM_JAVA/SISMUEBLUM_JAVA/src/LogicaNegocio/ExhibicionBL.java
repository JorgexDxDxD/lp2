/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.ExhibicionDA;
import Modelo.Exhibicion;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jorge
 */
public class ExhibicionBL {

    private ExhibicionDA access;
    
    public ExhibicionBL(){
        access = new ExhibicionDA();
    }
    
    public void registrarExhibicion(Exhibicion ex) throws SQLException {
        access.registrarExhibicion(ex);
    }
    
    public void eliminarExhibicion(Exhibicion get) throws SQLException  {
        access.eliminarExhibicion(get);
    }

    public ArrayList<Exhibicion> listarExhibicionesJuridico(int b, String nombre) throws SQLException  {
        return access.listarExhibicionesJuridico(b,nombre);
    }

    public ArrayList<Exhibicion> listarExhibicionesNatural(int b, String nombre) throws SQLException {
        return access.listarExhibicionesNatural(b,nombre);
    }

    public void restararExhibicion(Exhibicion get) throws SQLException {
        access.recuperarExhibicion(get);
    }
}
