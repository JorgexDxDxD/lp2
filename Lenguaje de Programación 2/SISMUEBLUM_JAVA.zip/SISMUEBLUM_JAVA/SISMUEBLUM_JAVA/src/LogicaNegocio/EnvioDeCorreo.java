/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.JOptionPane;

/**
 *
 * @author jorge
 */
public class EnvioDeCorreo {
    private String username;
    private String password;
    private Session s;
    
    public EnvioDeCorreo(String username,String password){
        this.username=username;
        this.password=password;
        Properties prop = new Properties();
        prop.put("mail.smtp.ssl.trust","smtp.gmail.com");
        prop.put("mail.smtp.auth",true);
        prop.put("mail.smtp.starttls.enable",true);
        prop.put("mail.smtp.host","smtp.gmail.com");
        prop.put("mail.smtp.port","587");
        
        s = Session.getInstance(prop, new javax.mail.Authenticator() {
            protected javax.mail.PasswordAuthentication getPasswordAuthentication(){
                return new javax.mail.PasswordAuthentication(username,password);
            }
            });
    }
    
    public void enviarMensaje(String para,String copia,String subject,String mensaje)throws Exception{
            Message msg = new MimeMessage(s);
            msg.setFrom(new InternetAddress("no-reply@gmail.com"));
            
            msg.setRecipients(Message.RecipientType.TO, 
                    InternetAddress.parse(para,false));
            if(!copia.isEmpty()) msg.setRecipients(Message.RecipientType.CC, 
                    InternetAddress.parse(copia,false));
            msg.setSubject(subject);
            msg.setText(mensaje);
            
            Transport.send(msg);
        
    }
}
