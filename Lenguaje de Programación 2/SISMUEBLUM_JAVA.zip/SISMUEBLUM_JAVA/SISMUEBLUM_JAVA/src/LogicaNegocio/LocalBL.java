/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.LocalDA;
import Modelo.Local;
import java.util.ArrayList;

/**
 *
 * @author alulab14
 */
public class LocalBL {
    private LocalDA lDA;
    public LocalBL(){
        lDA = new LocalDA();
    }
    public ArrayList<Local> getList(){
        return lDA.getLista();
    }
}
