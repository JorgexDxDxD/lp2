/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.NotificacionDA;
import Modelo.Notificacion;
import java.util.ArrayList;

/**
 *
 * @author ferp93
 */
public class NotificacionBL {
    
    private NotificacionDA da;
    
    public NotificacionBL(){
        da = new NotificacionDA();
    }
    
    public ArrayList<Notificacion> obtenerNotificacioneDeStock(){
        return da.obtenerNotificacioneDeStock();
    }
    public ArrayList<Notificacion> obtenerNotificacionDeVendedor(){
        return da.obetenerNotificacionVendedor();
    }
}
