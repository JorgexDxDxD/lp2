/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.ClienteDA;
import Modelo.*;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Lucks
 */
public class ClienteBL {
    private ClienteDA accesoCliente;
    public ClienteBL(){
        accesoCliente = new ClienteDA();
    }
    public ArrayList<Juridico> listarCliJ(){
        return accesoCliente.listarCliJ();
    }
    public ArrayList<Natural> listarCliN(){
        return accesoCliente.listarCliN();
    }
    public void agregarCliente(Cliente c){
        if(c instanceof Natural){
            Natural n = new Natural("","","","",0,c.getTelefono(),c.getCorreo(),c.getDireccion());
            n = (Natural) c;
            accesoCliente.agregarClienteN(n);
        }
        else{
            Juridico j = new Juridico("","","",0,c.getTelefono(),c.getCorreo(),c.getDireccion());
            j = (Juridico) c;
            accesoCliente.agregarClienteJ(j);
        }
    }
    

    public void modificarCliente(Cliente c){
        if(c instanceof Natural){
            Natural n = (Natural) c;
            accesoCliente.modificarClienteN(n);
        }
        else{
            Juridico j = (Juridico) c;
            accesoCliente.modificarClienteJ(j);
        }
    }
    
//    public ArrayList<Cliente> filtrarCliJ() {
//        return accesoCliente.filtrarCliJ();
//    }
//
//    public ArrayList<Cliente> filtrarCliN() {
//        return accesoCliente.filtrarCliN();
//        
//    }
    public ArrayList<Venta> historialCliente(Cliente c){
        return accesoCliente.historialCliente(c);
    }
    
    public int buscarCliente(String dato){
        if(dato.length() < 10){
            return accesoCliente.buscarClienteN(dato);
        }
        else{
            return accesoCliente.buscarClienteJ(dato);
        }
    }
    
    public int verificarClienteVendedor(int codV, int codC){
        return accesoCliente.verificarClienteVendedor(codV, codC);
    }
    
    public void reasignarClienteVendedor(int codV, int codC){
        accesoCliente.reasignarClienteVendedor(codV, codC);
    }
    
    public ArrayList<DetalleVenta> productosCliente(int idV) throws SQLException{
        return accesoCliente.productosCliente(idV);
    }
    
    public ArrayList<Juridico> filtrarJuridico( String ruc, String rs, String rep) throws SQLException{
        return accesoCliente.filtrarJuridico(ruc,rs,rep);
    }

    public ArrayList<Natural> filtrarNatural( String dni, String nomb, String apPat) throws SQLException {
        return accesoCliente.filtrarNatural(dni,nomb,apPat);
    }
}