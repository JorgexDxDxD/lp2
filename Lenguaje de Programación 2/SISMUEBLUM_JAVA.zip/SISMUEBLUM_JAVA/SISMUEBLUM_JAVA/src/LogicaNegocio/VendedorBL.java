/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.VendedorDA;
import Modelo.Vendedor;
import java.util.ArrayList;

/**
 *
 * @author Alvaro
 */
public class VendedorBL {
    
    private ArrayList<Vendedor> lista;
    private VendedorDA vDA;
    
    public VendedorBL(){
        vDA = new VendedorDA();
    }
    public ArrayList<Vendedor> getLista(){
        return vDA.listarList();
    }
    public void EliminarVendedor(int id){
        vDA.eliminarV(id);
    }
    
    public void crearVen(Vendedor v){
        vDA.crearVen(v);
    }
    public int actualizarVen(Vendedor v){
        return vDA.update(v);
    }
    public int reiniciarMontoAll(){
        return vDA.reiniciarMontoAll();
    }
    public int reniciarMonto(int id){
        return vDA.reiniciarMonto(id);
    }
}
