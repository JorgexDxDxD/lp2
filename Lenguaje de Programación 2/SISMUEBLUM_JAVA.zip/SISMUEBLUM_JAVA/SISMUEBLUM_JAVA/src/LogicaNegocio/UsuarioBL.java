/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.UsuarioDA;
import Modelo.*;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Frank7cj
 */
public class UsuarioBL {
    private UsuarioDA accesoUser;
    public UsuarioBL(){
        accesoUser = new UsuarioDA();
    }
    public ArrayList<Usuario> listarGer() throws SQLException{
        return accesoUser.listarGer();
    }
    public ArrayList<Usuario> listarGerFil(String nombre, String apellido,
            String dni, Integer prio) throws SQLException{
        return accesoUser.listarGerFilt(nombre, apellido, dni, prio);
    }
    public void crearGer(Usuario g) throws SQLException{
        accesoUser.crearGer(g);
    }
    public void modificarGer(Usuario g) throws SQLException{
        accesoUser.modificarGer(g);
    }
    public void eliminarGer(int idG) throws SQLException{
        accesoUser.eliminaGer(idG);
    }
}
