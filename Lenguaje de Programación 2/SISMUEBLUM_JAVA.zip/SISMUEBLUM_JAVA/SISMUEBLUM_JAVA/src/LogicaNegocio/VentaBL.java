/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

import AccesoDatos.VentaDA;
import Modelo.Juridico;
import Modelo.Natural;
import Modelo.Producto;
import Modelo.Venta;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ferp93
 */
public class VentaBL {
    private VentaDA da;
    
    public VentaBL(){
        da = new VentaDA();
    }
    
    public ArrayList<Producto> listarProductos (String nombreProducto) throws SQLException{
        return da.listarProductos(nombreProducto);
    }
    
    public ArrayList<Juridico> listarJuridicos (String nombreCliente, int idVendedor) throws SQLException{
        return da.listarJuridicos(nombreCliente, idVendedor);
    }
    
    public ArrayList<Natural> listarNaturales (String nombreCliente, int idVendedor) throws SQLException{
        return da.listarNaturales(nombreCliente, idVendedor);
    }
    
    public int registrarVenta(Venta venta) throws SQLException{
        return da.registrarVenta(venta);
    }
    
    public double obtenerMontoVendido(int id) throws SQLException{
        return da.obtenerMontoVendido(id);
    }
}
