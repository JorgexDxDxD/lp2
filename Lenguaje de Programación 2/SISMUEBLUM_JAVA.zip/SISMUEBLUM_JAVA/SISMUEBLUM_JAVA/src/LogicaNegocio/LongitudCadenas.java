/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LogicaNegocio;

/**
 *
 * @author jorge
 */
public class LongitudCadenas {
    public static int LongUsuario =44; // y password
    public static int LongInformacion =195;
    public static int LongCorreo =44;
    public static int LongDNI =9;
    public static int LongSexo =14;
    public static int LongNombreApellidos = 44;
    public static int LongMeta =4;
    public static int LongSeguroDomicilio =44;
    public static int LongTelefono =44;
    public static int LongDireccion =49;
    public static int LongRUC =11;
    public static int LongCantidad =8;
    public static int LongMensaje =400;
}
