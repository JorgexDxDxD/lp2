/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import Modelo.Usuario;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Frank7cj
 */
public class UserModel extends AbstractTableModel{
    private ArrayList<Usuario> lista = new ArrayList<>();
    private String[] columnNames = { "Nombre", "Apellido Paterno", "DNI","UserName","Prioridad"};
    public UserModel(ArrayList<Usuario> lista){
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        Usuario user = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: 
                return user.getNombre();
            case 1:
                return user.getApellidoPaterno();
            case 2:
                return user.getDni();
            case 3:
                return user.getUsername();
            case 4:
                return user.getPrioridad();
        }
        return null;
    }
    @Override
    public String getColumnName(int col){
        return columnNames[col];
    }
}
