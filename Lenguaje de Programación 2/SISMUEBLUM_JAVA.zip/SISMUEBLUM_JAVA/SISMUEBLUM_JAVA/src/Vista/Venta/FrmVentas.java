/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Venta;

import LogicaNegocio.LongitudCadenas;
import LogicaNegocio.VentaBL;
import Media.Disenho;
import Modelo.Cliente;
import Modelo.Juridico;
import Modelo.Natural;
import Modelo.Producto;
import Modelo.TipoDocDeVenta;
import Modelo.Vendedor;
import Modelo.Venta;
import Seguridad.ErrorLog;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ferp93
 */
public class FrmVentas extends javax.swing.JDialog {

    private List<javax.swing.JLabel> lblsCliente;
    private Cliente cliente;
    private VentaBL bl;
    private DefaultTableModel modeloTabla;
    private Venta venta;
    private String tipoDoc;
    private GenerarReporteVenta generadorReporte;
    private int codigoVendedor;
    private boolean flagModificacionTabla = false; //true solo mientras se elimina o se agrega una fila
    
    
    public FrmVentas(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    public FrmVentas(java.awt.Frame parent, boolean modal, Vendedor vendedor) throws SQLException {
        super(parent, modal);
        initComponents();
        //btnGenerarReporte.setEnabled(false);
        this.setLocationRelativeTo(null);
        Disenho d = new Disenho(this.getContentPane());
        bl = new VentaBL();
        NumberFormat formatter = new DecimalFormat("#0.00");
        
        labelMontoVendido.setText(labelMontoVendido.getText() + formatter.format(bl.obtenerMontoVendido(vendedor.getCodigoUsuario()) ));
        
        lblsCliente = new ArrayList<>();
        lblsCliente.add(lblTituloNombre);lblsCliente.add(lblTituloDireccion);lblsCliente.add(lblTituloRuc);
        lblsCliente.add(lblNombre);lblsCliente.add(lblDireccion);lblsCliente.add(lblRUC);
        for (javax.swing.JLabel label: lblsCliente) label.setVisible(false);
        
        cliente = null;
        
        modeloTabla = (DefaultTableModel) tablaProductos.getModel();
        modeloTabla.setRowCount(0);
        modeloTabla.addTableModelListener(
        new TableModelListener(){
            @Override
            public void tableChanged(TableModelEvent e) {
                System.out.println("Flag de agregado: " + flagModificacionTabla);
                if(!flagModificacionTabla){
                    String valor = tablaProductos.getModel().getValueAt(tablaProductos.getEditingRow(), 7).toString();
                    int cantidadPuntos = valor.length() - valor.replace(".", "").length();

                    if ((cantidadPuntos<=1) && (valor.charAt(valor.length() - 1)!='.') && 
                            (valor.charAt(0)!='.') && (!valor.isEmpty())){
                        //cuando es numero
                        if (!checkCotizacion.isSelected()){
                            if (venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getProducto().getStock()>=Double.parseDouble(valor)){
                                //se resta el precio del total
                                venta.setSubToltal(venta.getSubToltal() - venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getPrecioTotal());
                                //se edita la cantidad en la lista de lineas de producto
                                venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).setCantidad(Double.parseDouble(valor));
                                //se calcula el nuevo precio total de la linea
                                venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).calcularPrecioTotal();
                                //se suma el nuevo valor
                                venta.setSubToltal(venta.getSubToltal() + venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getPrecioTotal());
                                //se calcula el nuevo total de la venta
                                venta.setTotal(venta.getSubToltal()*1.18);
                                //se actualizan los labels
                                actualizarLabelsVenta();
                            } else { 
                                msgBox("No hay stock suficiente", "No se puede añadir el producto", "error");
                                flagModificacionTabla = true;
                                tablaProductos.getModel().setValueAt(venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getCantidad(), tablaProductos.getEditingRow(), 7);
                                flagModificacionTabla = false;
                            }
                        }else{
                            //se resta el precio del total
                            venta.setSubToltal(venta.getSubToltal() - venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getPrecioTotal());
                            //se edita la cantidad en la lista de lineas de producto
                            venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).setCantidad(Double.parseDouble(valor));
                            //se calcula el nuevo precio total de la linea
                            venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).calcularPrecioTotal();
                            //se suma el nuevo valor
                            venta.setSubToltal(venta.getSubToltal() + venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getPrecioTotal());
                            //se calcula el nuevo total de la venta
                            venta.setTotal(venta.getSubToltal()*1.18);
                            //se actualizan los labels
                            actualizarLabelsVenta();
                        }
                        
                    } else {
                        msgBox("Por favor ingrese un numero valido",
                            "El valor ingresado no es un numero", "advertencia");
                        flagModificacionTabla = true;
                        tablaProductos.getModel().setValueAt(venta.getAuxDetalleVenta().get(tablaProductos.getEditingRow()).getCantidad(), tablaProductos.getEditingRow(), 7);
                        flagModificacionTabla = false;
                    }
                }
            }
        });
        
        venta = new Venta();
        
        venta.setVendedor_Usuario_codigoUsuario1(vendedor);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtboxCliente = new javax.swing.JTextField();
        btnBuscarCliente = new javax.swing.JButton();
        lblTituloNombre = new javax.swing.JLabel();
        lblTituloRuc = new javax.swing.JLabel();
        lblTituloDireccion = new javax.swing.JLabel();
        lblNombre = new javax.swing.JLabel();
        lblDireccion = new javax.swing.JLabel();
        lblRUC = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        checkFactura = new javax.swing.JCheckBox();
        checkBoleta = new javax.swing.JCheckBox();
        checkCotizacion = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaProductos = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        btnGuardar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();
        btnGenerarReporte = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtboxProducto = new javax.swing.JTextField();
        btnBuscarProducto = new javax.swing.JButton();
        btnEliminarProducto = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        lblSubtotal = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblIGV = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        lblTotal = new javax.swing.JLabel();
        labelMontoVendido = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Nueva venta");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente"));

        jLabel1.setText("Nombre:");

        txtboxCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtboxClienteKeyTyped(evt);
            }
        });

        btnBuscarCliente.setText("Buscar");
        btnBuscarCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnBuscarClienteMousePressed(evt);
            }
        });

        lblTituloNombre.setText("Razón social:");

        lblTituloRuc.setText("RUC:");

        lblTituloDireccion.setText("Dirección:");

        lblNombre.setText("nombre");

        lblDireccion.setText("dirección");

        lblRUC.setText("ruc");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtboxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnBuscarCliente))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTituloNombre)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblNombre))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTituloDireccion)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblDireccion))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(lblTituloRuc)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblRUC)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtboxCliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarCliente))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTituloNombre)
                    .addComponent(lblNombre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTituloDireccion)
                    .addComponent(lblDireccion))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTituloRuc)
                    .addComponent(lblRUC))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Tipo de documento"));

        checkFactura.setText("Factura");
        checkFactura.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                checkFacturaMousePressed(evt);
            }
        });

        checkBoleta.setText("Boleta");
        checkBoleta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                checkBoletaMousePressed(evt);
            }
        });

        checkCotizacion.setSelected(true);
        checkCotizacion.setText("Cotización");
        checkCotizacion.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                checkCotizacionMousePressed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(checkFactura)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(checkBoleta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(checkCotizacion)
                .addGap(128, 128, 128))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(checkFactura)
                    .addComponent(checkBoleta)
                    .addComponent(checkCotizacion))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Unidad", "Marca", "Categoría", "Color", "P. unitario", "Cantidad", "P. total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaProductos.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tablaProductos);
        if (tablaProductos.getColumnModel().getColumnCount() > 0) {
            tablaProductos.getColumnModel().getColumn(0).setResizable(false);
            tablaProductos.getColumnModel().getColumn(1).setResizable(false);
            tablaProductos.getColumnModel().getColumn(1).setPreferredWidth(150);
            tablaProductos.getColumnModel().getColumn(2).setResizable(false);
            tablaProductos.getColumnModel().getColumn(2).setPreferredWidth(100);
            tablaProductos.getColumnModel().getColumn(3).setResizable(false);
            tablaProductos.getColumnModel().getColumn(4).setResizable(false);
            tablaProductos.getColumnModel().getColumn(4).setPreferredWidth(150);
            tablaProductos.getColumnModel().getColumn(5).setResizable(false);
            tablaProductos.getColumnModel().getColumn(6).setResizable(false);
            tablaProductos.getColumnModel().getColumn(7).setResizable(false);
            tablaProductos.getColumnModel().getColumn(8).setResizable(false);
        }

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        btnGuardar.setText("Guardar");
        btnGuardar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnGuardarMousePressed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnLimpiarMousePressed(evt);
            }
        });

        btnVolver.setText("Volver");
        btnVolver.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnVolverMousePressed(evt);
            }
        });

        btnGenerarReporte.setText("Reporte");
        btnGenerarReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarReporteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnGenerarReporte, javax.swing.GroupLayout.DEFAULT_SIZE, 141, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGenerarReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        jLabel5.setText("Producto:");

        txtboxProducto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtboxProductoKeyTyped(evt);
            }
        });

        btnBuscarProducto.setText("Buscar producto");
        btnBuscarProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnBuscarProductoMousePressed(evt);
            }
        });

        btnEliminarProducto.setText("Eliminar producto seleccionado");
        btnEliminarProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                btnEliminarProductoMousePressed(evt);
            }
        });

        jLabel8.setText("Subtotal: $");

        lblSubtotal.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblSubtotal.setText("0");

        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("IGV 18%: $");

        lblIGV.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblIGV.setText("0");

        jLabel12.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("Total: $");

        lblTotal.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        lblTotal.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblTotal.setText("0");

        labelMontoVendido.setText("Esta semana, hasta el momento, has vendido $ ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtboxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnBuscarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnEliminarProducto, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblIGV))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblTotal))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelMontoVendido, javax.swing.GroupLayout.PREFERRED_SIZE, 411, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblSubtotal)))
                        .addGap(32, 32, 32)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtboxProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscarProducto)
                    .addComponent(btnEliminarProducto))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(lblSubtotal)
                    .addComponent(labelMontoVendido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(lblIGV))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(lblTotal))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void checkCotizacionMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkCotizacionMousePressed
        btnGenerarReporte.setEnabled(true);    
            
        if (modeloTabla.getRowCount()>0 && (checkFactura.isSelected() || checkBoleta.isSelected())){
            //preguntar si realmente se quiere cambiar a cotizacion
            int confirmacion = JOptionPane.showConfirmDialog (null, 
                "Estás seguro que quieres cambiar a una cotización? Ten en cuenta para regresar nuevamente a una venta tendrá que eliminar los productos"
                ,"Warning", JOptionPane.YES_NO_OPTION);
            if(confirmacion!=0) {
                checkCotizacion.setSelected(!checkCotizacion.isSelected());
            }
            else {
                
                btnGenerarReporte.setEnabled(true);
                checkFactura.setSelected(false);
                checkBoleta.setSelected(false);
            }
        }else{
            checkFactura.setSelected(false);
            checkBoleta.setSelected(false);
            if (checkCotizacion.isSelected()){
                checkCotizacion.setSelected(false);
                
            
            }
        }
    }//GEN-LAST:event_checkCotizacionMousePressed

    private void checkBoletaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkBoletaMousePressed
        btnGenerarReporte.setEnabled(false);    
            
        if (modeloTabla.getRowCount()>0 && checkCotizacion.isSelected()){
            checkBoleta.setSelected(!checkBoleta.isSelected());
            msgBox("Por favor elimine los productos existentes antes de cambiar a una venta",
                    "Imposible de cambiar el tipo de documento", "advertencia");
            if(checkCotizacion.isSelected()){
                btnGenerarReporte.setEnabled(true);
            }
        }
        else{
            checkFactura.setSelected(false);
            checkCotizacion.setSelected(false);
            if (checkBoleta.isSelected()) checkBoleta.setSelected(false);
        }
        
    }//GEN-LAST:event_checkBoletaMousePressed

    private void checkFacturaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_checkFacturaMousePressed
        btnGenerarReporte.setEnabled(false);    
        
        if (cliente instanceof Natural){
            msgBox("El cliente seleccionado es del tipo natural. Por favor cambielo por uno "
                    + "juridico si es que la venta procede con factura.",
                    "Imposible de cambiar el tipo de documento", "advertencia");
            checkFactura.setSelected(false);
            
        }else if (modeloTabla.getRowCount()>0 && checkCotizacion.isSelected()){
            checkFactura.setSelected(!checkFactura.isSelected());
            msgBox("Por favor elimine los productos existentes antes de cambiar a una venta",
                    "Imposible de cambiar el tipo de documento", "advertencia");
            if(checkCotizacion.isSelected()){
                btnGenerarReporte.setEnabled(true);
            }
        }
        else{
            checkCotizacion.setSelected(false);
            checkBoleta.setSelected(false);
            if (checkFactura.isSelected()) checkFactura.setSelected(false);
        }
        
    }//GEN-LAST:event_checkFacturaMousePressed

    private void btnBuscarClienteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarClienteMousePressed
        ArrayList<Juridico> listaJuridico = new ArrayList<>();
        try {
            listaJuridico = bl.listarJuridicos(txtboxCliente.getText(), venta.getVendedor_Usuario_codigoUsuario1().getCodigoUsuario());
        } catch (SQLException ex) {
            Logger.getLogger(FrmVentas.class.getName()).log(Level.SEVERE, null, ex);
        }
        ArrayList<Natural> listaNatural = new ArrayList<>();
        try {
            listaNatural = bl.listarNaturales(txtboxCliente.getText(), venta.getVendedor_Usuario_codigoUsuario1().getCodigoUsuario());
        } catch (SQLException ex) {
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
       if ((listaNatural.size()+listaJuridico.size())>0){
           FrmBuscarCliente ventanaBuscarCliente = new FrmBuscarCliente((java.awt.Frame)this.getParent(), true, listaJuridico, listaNatural);
           ventanaBuscarCliente.setVisible(true);
       
           if(ventanaBuscarCliente.clienteSeleccionado != null) { 
                for (javax.swing.JLabel label: lblsCliente) label.setVisible(true);
                cliente = ventanaBuscarCliente.clienteSeleccionado;
                if (cliente instanceof Juridico) {
                    Juridico j = (Juridico) cliente;
                    lblNombre.setText(j.getRazon());
                    lblRUC.setText(j.getRuc());
                    lblDireccion.setText(j.getDireccion());

                    lblTituloNombre.setText("Razón social: ");
                    lblTituloRuc.setText("RUC: ");
                    lblTituloDireccion.setText("Dirección: ");
                    
                } else {
                    Natural n = (Natural) cliente;
                    lblNombre.setText(n.getNombre() + " "+ n.getApellidoPaterno() + " " + n.getApellidoMaterno());
                    lblRUC.setText(n.getDni());
                    lblDireccion.setText(n.getDireccion());

                    lblTituloNombre.setText("Nombre: ");
                    lblTituloRuc.setText("DNI: ");
                    lblTituloDireccion.setText("Dirección: ");
                    if (checkFactura.isSelected()){
                        checkFactura.setSelected(false);
                        checkCotizacion.setSelected(false);
                        checkBoleta.setSelected(true);
                    }
                }
            }
       } else msgBox("No hay resultados para la busqueda",
                    "Error en la busqueda", "advertencia");
       
       
       
    }//GEN-LAST:event_btnBuscarClienteMousePressed

    private void actualizarLabelsVenta(){
        NumberFormat formatter = new DecimalFormat("#0.00");
        lblTotal.setText(formatter.format(venta.getTotal()));
        lblSubtotal.setText(formatter.format(venta.getSubToltal()));
        lblIGV.setText(formatter.format(venta.getTotal()-venta.getSubToltal()));
        if (modeloTabla.getRowCount()==0){
            lblTotal.setText("0");
            lblSubtotal.setText("0");
            lblIGV.setText("0");
            venta.setSubToltal(0);
            venta.setTotal(0);
        }
    }
    private void btnBuscarProductoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBuscarProductoMousePressed
        ArrayList<Producto> lista = new ArrayList<>();
        try {
            lista = bl.listarProductos(txtboxProducto.getText());
        } catch (SQLException ex) {
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        if (lista.size()>0){
            FrmBuscarProductos ventanaBuscarProducto = new FrmBuscarProductos((java.awt.Frame)this.getParent(), true, lista, !checkCotizacion.isSelected());
            ventanaBuscarProducto.setVisible(true);
            if(ventanaBuscarProducto.productoSeleccionado != null) { //se añade producto
                //se chequea si el producto ya existe en la tabla
                boolean encontrado = false; for (auxLineaVenta aux: venta.getAuxDetalleVenta())
                    if (aux.getProducto().getCodigo() == ventanaBuscarProducto.productoSeleccionado.getCodigo()){
                        encontrado = true;
                        break;
                    }
                if (encontrado) msgBox("Por favor seleccione un producto que no haya sido agregado anteriormente", "Este producto ya fue agregado", "advertencia");
                else{
                    auxLineaVenta linea = new auxLineaVenta(ventanaBuscarProducto.productoSeleccionado, ventanaBuscarProducto.cantidad);
                    Object[] obj1 = new Object[9];
                    obj1[0] = linea.getProducto().getCodigo();
                    obj1[1] = linea.getProducto().getNombre();
                    obj1[2] = linea.getProducto().getUnidad();
                    obj1[3] = linea.getProducto().getProveedor();
                    obj1[4] = linea.getProducto().getFamilia();
                    obj1[5] = linea.getProducto().getColor();
                    obj1[6] = linea.getProducto().getPrecio();
                    obj1[7] = linea.getCantidad();
                    obj1[8] = linea.getPrecioTotal();
                    flagModificacionTabla = true;
                    modeloTabla.addRow(obj1);
                    flagModificacionTabla = false;
                    tablaProductos.setRowSelectionInterval(0, 0);
                    venta.getAuxDetalleVenta().add(linea);
                    venta.setSubToltal(venta.getSubToltal() + linea.getPrecioTotal());
                    venta.setTotal(venta.getSubToltal()*1.18);

                    actualizarLabelsVenta();
                }
            }
        } else msgBox("No hay resultados para la busqueda",
                    "Error en la busqueda", "advertencia");
        
    }//GEN-LAST:event_btnBuscarProductoMousePressed

    private void btnEliminarProductoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarProductoMousePressed
        if (modeloTabla.getRowCount()>0){
            auxLineaVenta linea = venta.getAuxDetalleVenta().get(tablaProductos.getSelectedRow());
            venta.setSubToltal(venta.getSubToltal() - linea.getPrecioTotal());
            venta.setTotal(venta.getSubToltal()*1.18);
            venta.getAuxDetalleVenta().remove(tablaProductos.getSelectedRow());
            flagModificacionTabla = true;
            modeloTabla.removeRow(tablaProductos.getSelectedRow());
            flagModificacionTabla = false;
            
            actualizarLabelsVenta();
        } 
        else msgBox("No hay productos para elminar",
                    "Imposible realizar acción", "advertencia");
    }//GEN-LAST:event_btnEliminarProductoMousePressed

    private void btnLimpiarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLimpiarMousePressed
        for (javax.swing.JLabel label: lblsCliente) label.setVisible(false);
        cliente = null;
        flagModificacionTabla = true;
        modeloTabla.setRowCount(0);
        flagModificacionTabla = false;
        lblTotal.setText("0");
        lblSubtotal.setText("0");
        lblIGV.setText("0");
        venta.setSubToltal(0);
        venta.setTotal(0);
        venta.getAuxDetalleVenta().clear();
    }//GEN-LAST:event_btnLimpiarMousePressed

    private void btnGuardarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnGuardarMousePressed
        if (modeloTabla.getRowCount()==0)
            msgBox("Por favor agregue al menos un producto", "Imposible de realizar acción", "advertencia");
        else if (cliente==null)
            msgBox("Por favor seleccione un cliente", "Imposible de realizar acción", "advertencia");
        else {
            if(checkCotizacion.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Cotizacion);
            else if (checkFactura.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Factura);
            else if (checkBoleta.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Boleta);
            venta.setCliente_codigoCliente(cliente);
            venta.setDireccionDeDespacho(cliente.getDireccion());
//            generadorReporte = new GenerarReporteVenta(venta, this);
//            generadorReporte.Generador();
            try {
                bl.registrarVenta(venta);
            } catch (SQLException ex) {
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
            msgBox("El registro ha sido realizado con éxito", venta.getTipoDoc().name() + " realizada", "informacion");
            this.dispose();
        }
    }//GEN-LAST:event_btnGuardarMousePressed

    private void btnVolverMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnVolverMousePressed
        this.dispose();
    }//GEN-LAST:event_btnVolverMousePressed

    private void btnGenerarReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarReporteActionPerformed
        if(venta.getAuxDetalleVenta().size()>0){
            if(checkCotizacion.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Cotizacion);
            else if (checkFactura.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Factura);
            else if (checkBoleta.isSelected()) venta.setTipoDoc(TipoDocDeVenta.Boleta);
            venta.setCliente_codigoCliente(cliente);
            venta.setDireccionDeDespacho(cliente.getDireccion());
            generadorReporte = new GenerarReporteVenta(venta, this);
            try {
                generadorReporte.Generador();
            } catch (IOException ex) {
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "No hay datos para mostrar", "Informacion", JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_btnGenerarReporteActionPerformed

    private void txtboxClienteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtboxClienteKeyTyped
        // TODO add your handling code here:
        if(txtboxCliente.getText().length()>=LongitudCadenas.LongNombreApellidos) {  
            evt.consume();
        }
    }//GEN-LAST:event_txtboxClienteKeyTyped

    private void txtboxProductoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtboxProductoKeyTyped
        // TODO add your handling code here:
        
        if(txtboxProducto.getText().length()>=LongitudCadenas.LongNombreApellidos) {  
            evt.consume();
        }
    }//GEN-LAST:event_txtboxProductoKeyTyped
    
    private static void msgBox(String infoMessage, String titleBar, String tipo)
    {
        int tipoMensaje = JOptionPane.PLAIN_MESSAGE;
        if (tipo.equals("advertencia")) tipoMensaje = JOptionPane.WARNING_MESSAGE;
        else if (tipo.equals("informacion")) tipoMensaje = JOptionPane.INFORMATION_MESSAGE;
        else if (tipo.equals("error")) tipoMensaje = JOptionPane.ERROR_MESSAGE;
        JOptionPane.showMessageDialog(null, infoMessage, titleBar, tipoMensaje);
    }
     

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmVentas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                FrmVentas dialog = new FrmVentas(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarCliente;
    private javax.swing.JButton btnBuscarProducto;
    private javax.swing.JButton btnEliminarProducto;
    private javax.swing.JButton btnGenerarReporte;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JButton btnVolver;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JCheckBox checkBoleta;
    private javax.swing.JCheckBox checkCotizacion;
    private javax.swing.JCheckBox checkFactura;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelMontoVendido;
    private javax.swing.JLabel lblDireccion;
    private javax.swing.JLabel lblIGV;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblRUC;
    private javax.swing.JLabel lblSubtotal;
    private javax.swing.JLabel lblTituloDireccion;
    private javax.swing.JLabel lblTituloNombre;
    private javax.swing.JLabel lblTituloRuc;
    private javax.swing.JLabel lblTotal;
    private javax.swing.JTable tablaProductos;
    private javax.swing.JTextField txtboxCliente;
    private javax.swing.JTextField txtboxProducto;
    // End of variables declaration//GEN-END:variables
}
