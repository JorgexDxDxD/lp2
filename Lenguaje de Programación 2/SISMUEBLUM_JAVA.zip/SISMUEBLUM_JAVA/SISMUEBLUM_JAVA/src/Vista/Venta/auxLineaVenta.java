/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Venta;

import Modelo.Producto;

/**
 *
 * @author ferp93
 */
public class auxLineaVenta {
    private Producto producto;
    private double cantidad;
    private double precioTotal;
    
    public auxLineaVenta(Producto producto, double cantidad){
        this.producto = producto;
        this.cantidad = cantidad;
        calcularPrecioTotal();
    }
    
    public void calcularPrecioTotal(){
        precioTotal = cantidad*producto.getPrecio();
    }
    
    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
    
    public double getCantidad() {
        return cantidad;
    }
    
    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }
    
    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }
    
}
