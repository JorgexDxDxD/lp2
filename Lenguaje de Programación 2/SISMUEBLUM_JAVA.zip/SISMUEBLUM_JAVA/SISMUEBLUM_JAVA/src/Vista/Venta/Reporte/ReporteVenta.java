/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Venta.Reporte;

import LogicaNegocio.VentaBL;
import Modelo.Producto;
import Modelo.Venta;
import static Vista.Vendedor.GenerarReporteClientes.indiceProductoActual2;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

/**
 *
 * @author Alvaro
 */
public class ReporteVenta implements JRDataSource{
    private int indice = -1;
    private Venta venta;
    private VentaBL vBL;
    private ArrayList<Producto> listaProductos;
    private LocalDateTime now;
    private DateTimeFormatter dtf;
    private final double igvconst = 1.18;
    public ReporteVenta(){
    
    }
    
    public ReporteVenta(Venta venta){
        this.venta = venta;
        dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
	now = LocalDateTime.now();
	//System.out.println(dtf.format(now)); //2016/11/16 12:08:43
    }
    private BigDecimal truncateDecimal(double x,int numberofDecimals)
{
    if ( x > 0) {
        return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_FLOOR);
    } else {
        return new BigDecimal(String.valueOf(x)).setScale(numberofDecimals, BigDecimal.ROUND_CEILING);
    }
}
    
    @Override
    public boolean next() throws JRException {
        return ++indice<venta.getAuxDetalleVenta().size();
    }

    @Override
    public Object getFieldValue(JRField jrf) {
        Object valor = null;
        DecimalFormat df = new DecimalFormat("#.00");
        try{
            if("codigoProducto".equals(jrf.getName())){
                valor = String.valueOf(venta.getAuxDetalleVenta().get(indice).getProducto().getCodigo());
            }else if("nombre".equals(jrf.getName())){
                valor = venta.getAuxDetalleVenta().get(indice).getProducto().getNombre();
            }else if("cantidad".equals(jrf.getName())){
                valor = String.valueOf(venta.getAuxDetalleVenta().get(indice).getCantidad());
            }else if("precio".equals(jrf.getName())){
                double precio = venta.getAuxDetalleVenta().get(indice).getProducto().getPrecio();
                valor = String.valueOf(df.format(precio));
            }else if("subtotal".equals(jrf.getName())){
                double subtotal = venta.getAuxDetalleVenta().get(indice).getCantidad()*
                        venta.getAuxDetalleVenta().get(indice).getProducto().getPrecio();
                valor = String.valueOf(df.format(subtotal));
            }else if("total".equals(jrf.getName())){
                valor = String.valueOf(df.format(venta.getTotal()));
            }else if("totalsinigv".equals(jrf.getName())){
                valor = String.valueOf(df.format(venta.getTotal()/igvconst));
            }else if("titulo".equals(jrf.getName())){
                valor = venta.getTipoDoc().toString();
            }else if("vendedor".equals(jrf.getName())){
                valor = venta.getVendedor_Usuario_codigoUsuario1().getNombre() + " " + 
                        venta.getVendedor_Usuario_codigoUsuario1().getApellidoPaterno();
            }else if("fechahoy".equals(jrf.getName())){
                valor = String.valueOf(dtf.format(now));
            }
        }catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return valor;
    }
}
