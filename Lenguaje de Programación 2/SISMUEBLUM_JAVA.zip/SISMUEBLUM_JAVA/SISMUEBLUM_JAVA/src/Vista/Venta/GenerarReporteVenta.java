/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Venta;

import Modelo.Venta;
import Vista.Venta.Reporte.ReporteVenta;
import java.util.HashMap;
import javax.swing.JDialog;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import java.awt.Image;
import java.io.IOException;
import javax.swing.ImageIcon;
/**
 *
 * @author Alvaro
 */
public class GenerarReporteVenta {
    private Venta venta;
    private final ReporteVenta reporte;
    private final FrmVentas  frame;
    private final String ruta = "/Vista/Venta/Reporte/JReporteVenta.jasper";
    public GenerarReporteVenta(Venta venta,FrmVentas frm){
        this.venta = venta;
        reporte = new ReporteVenta(venta);
        this.frame = frm;
//        for(int i=0;i<venta.getAuxDetalleVenta().size();i++){
//            System.out.println(((venta.getAuxDetalleVenta().get(i)).getProducto()).getCodigo());
//        }
    }
    
    public void setVenta(Venta venta){
        this.venta = venta;
    }
    public void Generador() throws IOException{
        try{
            JasperReport jr;
            JasperPrint jprint;
            jr=(JasperReport)JRLoader.loadObject(getClass().getResource(ruta));
            Image img =  new ImageIcon(this.getClass().getResource("/Media/logo2.jpg")).getImage();
            HashMap map = new HashMap();
            map.put("image",img); 
            JasperPrint jasperPrint = JasperFillManager.fillReport(jr, map, reporte); 
            //jprint=JasperFillManager.fillReport(jr, null,reporte);
            
            JasperViewer jview=new JasperViewer(jasperPrint,false);
            //jview.setTitle(String.valueOf(venta.getTipoDoc()));
            JDialog dialog = new JDialog(frame,true);//the owner
            
            dialog.setContentPane(jview.getContentPane());

            dialog.setSize(jview.getSize());
            dialog.setVisible(true);
//
//            JRExporter exporter = new JRPdfExporter();  
//            exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint); 
//            exporter.setParameter(JRExporterParameter.OUTPUT_FILE, new java.io.File("reporte2PDF.pdf")); 
//            exporter.exportReport();
        }catch(JRException ex){
            System.out.println(ex.getMessage());
        } 
    }
}
