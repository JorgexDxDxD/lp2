/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Clientes;
import Vista.Clientes.Exhibicion.*;
import LogicaNegocio.ClienteBL;
import LogicaNegocio.VentaBL;
import Media.Disenho;
import java.awt.Dimension;
import java.util.*;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import Modelo.*;
import Seguridad.ErrorLog;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import javax.swing.JFileChooser;
/**
 *
 * @author jorge
 */
public class GestorClientes extends javax.swing.JFrame {

    private int XN =1;
    private int XJ =2;
    private int prioridad;
    private int codigo;
    private javax.swing.JFrame parent;
    private ClienteBL cbl;
    private VentaBL vbl;
    private ArrayList<Natural> lNatural;
    private ArrayList<Juridico> lJuridico;
//    private ArrayList<Natural> fNatural;
//    private ArrayList<Juridico> fJuridico;
    private Usuario user;
    private TablaNatural Tabla1;  
    private TablaJuridico Tabla2;  
    
    
    public void setParent(javax.swing.JFrame par ){
        this.parent = par;
    }
    public void setPrioridad(int prioridad){
        this.prioridad= prioridad;   
    }
    public int getPriordad(){
        return this.prioridad;
    }
    public void setCodigo(int prioridad){
        this.codigo= prioridad;
    }
    public int getCodigo(){
        return this.codigo;
    }
    
    public void actualizarListas(){
        lNatural = cbl.listarCliN();
        lJuridico = cbl.listarCliJ();
        String matrizN[][]= new String[lNatural.size()][7];
        String matrizJ[][]= new String[lJuridico.size()][7];
        int j=0,k=0;
        for (int i = 0; i< lNatural.size();i++ ){
                matrizN[j][0]=((Natural)(lNatural.get(i))).getDni();
                matrizN[j][1]=((Natural)(lNatural.get(i))).getNombre();
                matrizN[j][2]=((Natural)(lNatural.get(i))).getApellidoPaterno();
                matrizN[j][3]=((Natural)(lNatural.get(i))).getApellidoMaterno();
                matrizN[j][4]=((Natural)(lNatural.get(i))).getTelefono();
                matrizN[j][5]=((Natural)(lNatural.get(i))).getCorreo();
                matrizN[j][6]=((Natural)(lNatural.get(i))).getDireccion();
                j++;
        }
        for(int i = 0; i< lJuridico.size();i++ ) {  
                matrizJ[k][0]=((Juridico)(lJuridico.get(i))).getRuc();
                matrizJ[k][1]=((Juridico)(lJuridico.get(i))).getRazon();
                matrizJ[k][2]=((Juridico)(lJuridico.get(i))).getRepresentante();
                matrizJ[k][3]=((Juridico)(lJuridico.get(i))).getTelefono();
                matrizJ[k][4]=((Juridico)(lJuridico.get(i))).getCorreo();
                matrizJ[k][5]=((Juridico)(lJuridico.get(i))).getDireccion();
                k++;
        }
        Tabla1.setModel(matrizN);
        Tabla2.setModel(matrizJ);
    }
    
    
    public void filtrarListas(int codU){
        try {
            lNatural = vbl.listarNaturales("", codU);
            lJuridico = vbl.listarJuridicos("", codU);
            String matrizN[][]= new String[lNatural.size()][7];
            String matrizJ[][]= new String[lJuridico.size()][7];
            int j=0,k=0;
            int codV;
            for (int i = 0; i< lNatural.size();i++ ){
                matrizN[j][0]=((Natural)(lNatural.get(i))).getDni();
                matrizN[j][1]=((Natural)(lNatural.get(i))).getNombre();
                matrizN[j][2]=((Natural)(lNatural.get(i))).getApellidoPaterno();
                matrizN[j][3]=((Natural)(lNatural.get(i))).getApellidoMaterno();
                matrizN[j][4]=((Natural)(lNatural.get(i))).getTelefono();
                matrizN[j][5]=((Natural)(lNatural.get(i))).getCorreo();
                matrizN[j][6]=((Natural)(lNatural.get(i))).getDireccion();
                j++;
            }
            for(int i = 0; i< lJuridico.size();i++ ) { 
                matrizJ[k][0]=((Juridico)(lJuridico.get(i))).getRuc();
                matrizJ[k][1]=((Juridico)(lJuridico.get(i))).getRazon();
                matrizJ[k][2]=((Juridico)(lJuridico.get(i))).getRepresentante();
                matrizJ[k][3]=((Juridico)(lJuridico.get(i))).getTelefono();
                matrizJ[k][4]=((Juridico)(lJuridico.get(i))).getCorreo();
                matrizJ[k][5]=((Juridico)(lJuridico.get(i))).getDireccion();
                k++;
            }  
            Tabla1.setModel(matrizN);
            Tabla2.setModel(matrizJ);
        } catch (SQLException ex) {
            ErrorLog.registrarError(ex.getMessage());
            JOptionPane.showMessageDialog(null, "Conexión fallada con la BD", "Error",
            JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void filtrarTablaNatural(String dni,String nomb,String apPat){
        try {
            lNatural = cbl.filtrarNatural( dni,nomb,apPat);
            String matrizN[][]= new String[lNatural.size()][7];
            int j=0,k=0;
            int codV;
            for (int i = 0; i< lNatural.size();i++ ){
                matrizN[j][0]=((Natural)(lNatural.get(i))).getDni();
                matrizN[j][1]=((Natural)(lNatural.get(i))).getNombre();
                matrizN[j][2]=((Natural)(lNatural.get(i))).getApellidoPaterno();
                matrizN[j][3]=((Natural)(lNatural.get(i))).getApellidoMaterno();
                matrizN[j][4]=((Natural)(lNatural.get(i))).getTelefono();
                matrizN[j][5]=((Natural)(lNatural.get(i))).getCorreo();
                matrizN[j][6]=((Natural)(lNatural.get(i))).getDireccion();
                j++;
            }
            Tabla1.setModel(matrizN);
        } catch (SQLException ex) {
            ErrorLog.registrarError(ex.getMessage());
            JOptionPane.showMessageDialog(null, "Conexión fallada con la BD", "Error",
            JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void filtrarTablaJuridico(String ruc,String rs,String rep){
        try {
            lJuridico = cbl.filtrarJuridico( ruc,rs,rep);
            String matrizJ[][]= new String[lJuridico.size()][7];
            int j=0,k=0;
            int codV;
            for(int i = 0; i< lJuridico.size();i++ ) { 
                matrizJ[k][0]=((Juridico)(lJuridico.get(i))).getRuc();
                matrizJ[k][1]=((Juridico)(lJuridico.get(i))).getRazon();
                matrizJ[k][2]=((Juridico)(lJuridico.get(i))).getRepresentante();
                matrizJ[k][3]=((Juridico)(lJuridico.get(i))).getTelefono();
                matrizJ[k][4]=((Juridico)(lJuridico.get(i))).getCorreo();
                matrizJ[k][5]=((Juridico)(lJuridico.get(i))).getDireccion();
                k++;
            }  
            Tabla2.setModel(matrizJ);
        } catch (SQLException ex) {
            ErrorLog.registrarError(ex.getMessage());
            JOptionPane.showMessageDialog(null, "Conexión fallada con la BD", "Error",
            JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void verificarPrioridad(int prio, int cod){
        if(prio== 1 || prio== 2){
            actualizarListas();
        }
        else{
            filtrarListas(cod);
        }
    }
    
    public GestorClientes(Usuario user) {
        initComponents();
        Disenho di = new Disenho(this.getContentPane());
        this.setIconImage (new ImageIcon("src/media/iconoSM.png").getImage());
        this.setLocationRelativeTo(null);
        prioridad = user.getPrioridad();
        codigo = user.getCodigoUsuario();
        
        ModificarCliente.setEnabled(false);
        BuscarCliente.setEnabled(false);
        
        Tabla1 = new TablaNatural();
        Tabla2 = new TablaJuridico();
        Tabla1.setParent(this);
        Tabla2.setParent(this);
        
        Dimension d = jDesktopPane1.getSize();
        
        Tabla1.setSize(d);
        Tabla2.setSize(d);
        Tabla2.setVisible(false);
        Tabla1.setVisible(true);
        jDesktopPane1.add(Tabla1);
        jDesktopPane1.add(Tabla2);
        
        cbl = new ClienteBL();
        vbl = new VentaBL();
        verificarPrioridad(prioridad,codigo);
        
        ModificarCliente.setEnabled(false);
        BuscarCliente.setEnabled(false);
        
        switch (prioridad) {
            case 2:
                Reasignar.setEnabled(true);
                RegistrarExhibicion.setEnabled(false);
                BuscarCliente.setEnabled(false);
                AgregarCliente.setEnabled(false);
                ModificarCliente.setEnabled(false);
                botonExportar.setEnabled(true);
                break;
            case 1:
                Reasignar.setEnabled(true);
                RegistrarExhibicion.setEnabled(true);
                BuscarCliente.setEnabled(true);
                AgregarCliente.setEnabled(true);
                ModificarCliente.setEnabled(true);
                botonExportar.setEnabled(true);
                break;
            case 3:
                Reasignar.setEnabled(false);
                RegistrarExhibicion.setEnabled(true);
                BuscarCliente.setEnabled(true);
                AgregarCliente.setEnabled(true);
                ModificarCliente.setEnabled(true);
                botonExportar.setEnabled(false);
                break;
            default:
                JOptionPane.showMessageDialog(this, "Usuario no es vendedor o gerente");
                Reasignar.setEnabled(false);
                RegistrarExhibicion.setEnabled(false);
                BuscarCliente.setEnabled(false);
                AgregarCliente.setEnabled(false);
                ModificarCliente.setEnabled(false);
                botonExportar.setEnabled(false);
                break;       
        }
        JTable TN = Tabla1.getTabla();
        JTable TJ = Tabla2.getTabla();
        TN.setDefaultEditor(Object.class, null);
        TJ.setDefaultEditor(Object.class, null);
        
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        GestorClientes frame = this;
        javax.swing.JFrame padre = parent;
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                parent.setEnabled(true);
                frame.dispose();
            }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jDesktopPane1 = new javax.swing.JDesktopPane();
        jComboBox1 = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        AgregarCliente = new javax.swing.JButton();
        ModificarCliente = new javax.swing.JButton();
        BuscarCliente = new javax.swing.JButton();
        Reasignar = new javax.swing.JButton();
        RegistrarExhibicion = new javax.swing.JButton();
        botonExportar = new javax.swing.JButton();
        gestionarExhibiciones = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Gestión de Clientes");
        setMaximumSize(new java.awt.Dimension(941, 501));
        setMinimumSize(new java.awt.Dimension(941, 501));
        setResizable(false);

        jPanel1.setMaximumSize(new java.awt.Dimension(945, 501));
        jPanel1.setMinimumSize(new java.awt.Dimension(945, 501));

        jDesktopPane1.setForeground(new java.awt.Color(240, 240, 240));
        jDesktopPane1.setMaximumSize(new java.awt.Dimension(697, 468));
        jDesktopPane1.setMinimumSize(new java.awt.Dimension(697, 468));
        jDesktopPane1.setVerifyInputWhenFocusTarget(false);

        jComboBox1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cliente Natural", "Cliente Juridico" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jDesktopPane1.setLayer(jComboBox1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jDesktopPane1Layout = new javax.swing.GroupLayout(jDesktopPane1);
        jDesktopPane1.setLayout(jDesktopPane1Layout);
        jDesktopPane1Layout.setHorizontalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(499, Short.MAX_VALUE))
        );
        jDesktopPane1Layout.setVerticalGroup(
            jDesktopPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jDesktopPane1Layout.createSequentialGroup()
                .addGap(155, 155, 155)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N

        AgregarCliente.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        AgregarCliente.setText("Agregar Cliente");
        AgregarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarClienteActionPerformed(evt);
            }
        });

        ModificarCliente.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        ModificarCliente.setText("Modificar Cliente");
        ModificarCliente.setToolTipText("");
        ModificarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarClienteActionPerformed(evt);
            }
        });

        BuscarCliente.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        BuscarCliente.setText("<html>\n<center>Ver Detalles\n<center>de un Cliente\n</html>");
        BuscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarClienteActionPerformed(evt);
            }
        });

        Reasignar.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        Reasignar.setText("<html>\n<center>Reasignar Vendedor\n<center>de un cliente\n</html>");
        Reasignar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReasignarActionPerformed(evt);
            }
        });

        RegistrarExhibicion.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        RegistrarExhibicion.setText("Registrar Exhibición");
        RegistrarExhibicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarExhibicionActionPerformed(evt);
            }
        });

        botonExportar.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        botonExportar.setText("Exportar clientes");
        botonExportar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonExportarActionPerformed(evt);
            }
        });

        gestionarExhibiciones.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        gestionarExhibiciones.setText("Gestionar Exhibiciones");
        gestionarExhibiciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gestionarExhibicionesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(gestionarExhibiciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(botonExportar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BuscarCliente, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(RegistrarExhibicion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ModificarCliente, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Reasignar, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AgregarCliente, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(AgregarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RegistrarExhibicion, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ModificarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BuscarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(gestionarExhibiciones, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(botonExportar, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Reasignar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jDesktopPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 450, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>                        

    private void AgregarClienteActionPerformed(java.awt.event.ActionEvent evt) {                                               
        // TODO add your handling code here:  
        int valor = 0;
        if(prioridad == 3){
            valor = codigo;
        }
        AgregarCliente aC = new AgregarCliente(this, true, valor);
        aC.setParent(this);
        aC.setVisible(true);
        this.setEnabled(false);
    }                                              

    private void RegistrarExhibicionActionPerformed(java.awt.event.ActionEvent evt) {                                                    
        // TODO add your handling code here:
        int indices =-1;
        if(Tabla1.isVisible()){
            indices=Tabla1.getSeleccion();
            if (indices >=0){
                Natural nat = (Natural) lNatural.get(indices);
                RegistrarExhibicion exh = new RegistrarExhibicion(this, true,nat);
                exh.setVisible(true);
                exh.setParent(this);
                Tabla1.setVisible(false);
                Tabla1.setVisible(true);  
                Tabla1.deselec();        
                this.setEnabled(false);
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para registrar exhibición");
            }
        }
        else if(Tabla2.isVisible()){
            indices=Tabla2.getSeleccion();
            if (indices >=0){
                Juridico jur = (Juridico) lJuridico.get(indices);
                RegistrarExhibicion exh = new RegistrarExhibicion(this, true,jur);
                exh.setVisible(true);
                exh.setParent(this);
                Tabla2.setVisible(false);
                Tabla2.setVisible(true);  
                Tabla2.deselec();        
                this.setEnabled(false);
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para registrar exhibición");
            }
        }
        else JOptionPane.showMessageDialog(this, "No hay tabla de clientes activa");
    }                                                   

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {                                           
        // TODO add your handling code here:
        int a = jComboBox1.getSelectedIndex();
        jDesktopPane1.setVisible(true);
        if (a==XN-1){
            Tabla2.setVisible(false);
            Tabla1.setVisible(true);
            ModificarCliente.setEnabled(true);
            BuscarCliente.setEnabled(true);
            RegistrarExhibicion.setEnabled(true);
        }
        else if (a==XJ-1){
            Tabla1.setVisible(false);
            Tabla2.setVisible(true);
            ModificarCliente.setEnabled(true);
            BuscarCliente.setEnabled(true);
            RegistrarExhibicion.setEnabled(true);
        }
    }                                          

    private void BuscarClienteMousePressed(java.awt.event.MouseEvent evt) {                                           
        // TODO add your handling code here:
    }                                          

    private void RegistrarExhibicionMousePressed(java.awt.event.MouseEvent evt) {                                                 
        // TODO add your handling code here:
    }                                                

    private void ModificarClienteMousePressed(java.awt.event.MouseEvent evt) {                                              
        // TODO add your handling code here:
    }                                             

    private void jComboBox1MousePressed(java.awt.event.MouseEvent evt) {                                        
        // TODO add your handling code here:
    }                                       

    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {                                      
        // TODO add your handling code here:
        parent.setEnabled(true);
        this.dispose();
    }                                     


    private void ReasignarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
        int indices =-1;
        TablaNatural Tabla1 = (TablaNatural)(jDesktopPane1.getComponent(XN));
        TablaJuridico Tabla2 = (TablaJuridico)(jDesktopPane1.getComponent(XJ));
        Cliente c;
        //int indices ;
        if(Tabla1.isVisible()){
            indices=Tabla1.getSeleccion();         
            if (indices >=0){
                JTable TN = Tabla1.getTabla();
                c = lNatural.get(TN.getSelectedRow());
                Tabla1.setVisible(false);
                Tabla1.setVisible(true);  
                Tabla1.deselec();
                FrmReasignarVendedor ventana = new FrmReasignarVendedor(this, true, c);
                ventana.setVisible(true);
                ventana.setParent(this); 
                Tabla1.deselec();
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para cambiar de vendedor");
            }
        }
        else if(Tabla2.isVisible()){
            indices=Tabla2.getSeleccion();
            if (indices >= 0){
                JTable TJ = Tabla2.getTabla();
                c = lJuridico.get(TJ.getSelectedRow());
                Tabla2.setVisible(false);
                Tabla2.setVisible(true);  
                Tabla2.deselec();
                FrmReasignarVendedor ventana = new FrmReasignarVendedor(this, true, c);
                ventana.setVisible(true);
                ventana.setParent(this);
                Tabla2.deselec();
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para cambiar de vendedor");
            }
        }
        else JOptionPane.showMessageDialog(this, "No hay tabla de clientes activa");
    }                                         

    private void ModificarClienteActionPerformed(java.awt.event.ActionEvent evt) {                                                 
        // TODO add your handling code here:
        TablaNatural Tabla1 = (TablaNatural)(jDesktopPane1.getComponent(XN));
        TablaJuridico Tabla2 = (TablaJuridico)(jDesktopPane1.getComponent(XJ));
        Cliente c;
        int indices ;
        if(Tabla1.isVisible()){
            indices=Tabla1.getSeleccion();
            if (indices >= 0){
                JTable TN = Tabla1.getTabla();
                c = lNatural.get(TN.getSelectedRow());
                Tabla1.setVisible(false);
                Tabla1.setVisible(true);  
                Tabla1.deselec();
                ModificarClienteNatural modCliente = new ModificarClienteNatural(this, true, c);
                modCliente.setVisible(true);
                modCliente.setParent(this);
                verificarPrioridad(prioridad,codigo);
            }
            else {
                JOptionPane.showMessageDialog(this, "Seleccione un cliente");
                Tabla1.deselec();
            }
        }
        else if(Tabla2.isVisible()){
            indices=Tabla2.getSeleccion();
            if (indices >= 0){
                JTable TJ = Tabla2.getTabla();
                c = lJuridico.get(TJ.getSelectedRow());
                Tabla2.setVisible(false);
                Tabla2.setVisible(true);  
                Tabla2.deselec();
                ModificarClienteJuridico modCliente = new ModificarClienteJuridico(this, true, c);
                modCliente.setVisible(true);
                modCliente.setParent(this);
                verificarPrioridad(prioridad,codigo);
            }
            else {
                JOptionPane.showMessageDialog(this, "Seleccione un cliente");
                Tabla2.deselec();
            }
        }
        else {
             JOptionPane.showMessageDialog(this, "Escoja una tabla de clientes primero");
        }
    }                                                

    private void BuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {                                              
        // TODO add your handling code here:
        TablaNatural Tabla1 = (TablaNatural)(jDesktopPane1.getComponent(XN));
        TablaJuridico Tabla2 = (TablaJuridico)(jDesktopPane1.getComponent(XJ));
        Cliente c;
        int indice;
        if(Tabla1.isVisible()){
            JTable TN = Tabla1.getTabla();
            indice= TN.getSelectedRow();
            if (indice == -1) {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para consultar");
                return;
            }
            c = lNatural.get(indice);
            if (c.getCodigoCliente() != 0){
                VerDetalles det = new VerDetalles(this, true, c);
                det.setParent(this);
                det.setVisible(true);
                Tabla1.setVisible(false);

                Tabla1.setVisible(true);  
                Tabla1.deselec();
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para consultar");
            }
        }
        else if(Tabla2.isVisible()){
            JTable TJ = Tabla2.getTabla();
            indice= TJ.getSelectedRow();
            if (indice == -1) {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para consultar");
                return;
            }
            c = lJuridico.get(indice);
            if (c.getCodigoCliente() != 0){
                VerDetalles det = new VerDetalles(this, true, c);
                det.setParent(this);
                det.setVisible(true);
                Tabla2.setVisible(false);
                Tabla2.setVisible(true);  
                Tabla2.deselec();
            }
            else {
                JOptionPane.showMessageDialog(this, "No ha seleccionado ningún cliente para consultar");
            }
        }
        else JOptionPane.showMessageDialog(this, "No hay tabla de clientes activa");
    }                                             

    private void botonExportarActionPerformed(java.awt.event.ActionEvent evt) {                                              

        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("Elegir una carpeta");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);
        chooser.setCurrentDirectory(new File (System.getProperty("user.home")));
        chooser.setApproveButtonText("Guardar");
        
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            FileWriter archivo = null;
            try {
                if(jComboBox1.getSelectedIndex()==0){
                    ArrayList<Natural> listaNatural = cbl.listarCliN();
                    String ruta = chooser.getSelectedFile()+System.getProperty("file.separator") +"Clientes naturales.csv";
                    archivo = new FileWriter(ruta);
                    archivo.write("DNI,Nombre,A. paterno,A. materno,Telefono,Correo,Direccion"+"\n");
                    for (Natural c: listaNatural){
                        String linea = c.getDni()+','+c.getNombre()+','+c.getApellidoPaterno()+
                            ','+c.getApellidoMaterno()+','+c.getTelefono()+','+c.getCorreo()+
                            ','+c.getDireccion();
                        archivo.write(linea + "\n");
                    }
                } else {
                    ArrayList<Juridico> listaJuridico = cbl.listarCliJ();
                    String ruta = chooser.getSelectedFile()+System.getProperty("file.separator") +"clientes juridicos.csv";
                    archivo = new FileWriter(ruta);
                    archivo.write("RUC,Razon social,Representante,Teléfono,Correo,Direccion"+"\n");
                    for (Juridico c: listaJuridico){
                        String linea = c.getRuc()+','+c.getRazon()+','+c.getRepresentante()+
                            ','+c.getTelefono()+','+c.getCorreo()+','+c.getDireccion();
                        archivo.write(linea + "\n");
                    }
                }
                
                archivo.close();
            } catch (IOException ex) {
                    ErrorLog.registrarError(ex.getMessage());
                    JOptionPane.showMessageDialog(null, "No se pudo exportar la BD", "Error",
                    JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    archivo.close();
                } catch (IOException ex) {
                    ErrorLog.registrarError(ex.getMessage());
                    JOptionPane.showMessageDialog(null, "No se pudo cerrar el archivo", "Error",
                    JOptionPane.ERROR_MESSAGE);
                
                }
            }
        }
    }                                             

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
        parent.setEnabled(true);
        this.dispose();
    }                                        

    private void gestionarExhibicionesActionPerformed(java.awt.event.ActionEvent evt) {                                                      
        // TODO add your handling code here:
        GestorExhibicion GE = new GestorExhibicion(this, true);
        GE.setVisible(true);
    }                                                     

    // Variables declaration - do not modify                     
    private javax.swing.JButton AgregarCliente;
    private javax.swing.JButton BuscarCliente;
    private javax.swing.JButton ModificarCliente;
    private javax.swing.JButton Reasignar;
    private javax.swing.JButton RegistrarExhibicion;
    private javax.swing.JButton botonExportar;
    private javax.swing.JButton gestionarExhibiciones;
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JDesktopPane jDesktopPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration                   
}