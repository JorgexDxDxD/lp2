/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Clientes.Exhibicion;

import Modelo.*;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;


/**
 *
 * @author jorge
 */
public class ExhibicionModel extends AbstractTableModel{
    private ArrayList<Exhibicion> lista = new ArrayList<>();
    private String[] columnNames = { "Nombre o RazónSocial", "DNI o RUC", "Fecha Inicio Contrato","Periodo Semanal"};
    public ExhibicionModel(ArrayList<Exhibicion> listaExh){
        this.lista = listaExh;
    }
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        Exhibicion ex = lista.get(rowIndex);
        switch (columnIndex) {
            case 0: 
                if (ex.getCliente_codigoCliente() instanceof Natural){
                    Natural n = (Natural) ex.getCliente_codigoCliente();
                    return n.getNombre();
                }
                else{
                    Juridico j = (Juridico) ex.getCliente_codigoCliente();
                    return j.getRazon();
                }
            case 1:
                if (ex.getCliente_codigoCliente() instanceof Natural){
                    Natural n = (Natural) ex.getCliente_codigoCliente();
                    return n.getDni();
                }
                else{
                    Juridico j = (Juridico) ex.getCliente_codigoCliente();
                    return j.getRuc();
                }
            case 2:
                return ex.getFechaIniContrato();
            case 3:
                return "De " + ex.getDiaIni().toString()+" a " +ex.getDiaFin().toString();
        }
        return null;
    }
    @Override
    public String getColumnName(int col){
        return columnNames[col];
    }
}

