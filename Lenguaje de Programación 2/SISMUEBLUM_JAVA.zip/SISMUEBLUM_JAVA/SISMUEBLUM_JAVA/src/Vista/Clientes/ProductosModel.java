/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Clientes;

import Modelo.DetalleProd;
import Modelo.Producto;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jorge
 */
public class ProductosModel extends AbstractTableModel{
    private ArrayList<DetalleProd> lista = new ArrayList<>();
    private String[] columnNames = { "Codigo", "Nombre", "Cantidad","Unidad","Stock Actual"};
    public ProductosModel(ArrayList<DetalleProd> lista){
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return lista.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        DetalleProd det = lista.get(rowIndex);
        switch (columnIndex) {
            case 0:                
                return det.getProducto_codigo().getCodigo();
            case 1:
                return det.getProducto_codigo().getNombre();
            case 2:
                return det.getCantidad();
            case 3:
                return det.getProducto_codigo().getUnidad();
            case 4:
                return det.getProducto_codigo().getStock();
        }
        return null;
    }
    @Override
    public String getColumnName(int col){
        return columnNames[col];
    }
}


