/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Vendedor;

import Modelo.Cliente;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;
import Modelo.Producto;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;




/**
 *
 * @author Alvaro
 */
public class GenerarReporteClientes implements JRDataSource{
    private List<Object[]> lista;
    private List<Object[]> lista2;
    private boolean flag;
    private boolean ret2;
    private boolean ret;
    private ArrayList<Integer> lista_normales;
//    private List<Integer> cantidad = new ArrayList<>();
    public static int indiceProductoActual = -1;
    public static int indiceProductoActual2 = -1;
   // private double total;
    private String nombreVendedor = null;
    public void setListaNormales(ArrayList<Integer> listaExt){
        this.lista_normales = listaExt;
    }
    public void setnombreVendedor(String nombre){
        nombreVendedor = "REPORTE VENDEDOR " + nombre;
    }
    public GenerarReporteClientes(){
        //total = 0;
        lista = new ArrayList<Object[]>();
        lista2 = new ArrayList<Object[]>();
        this.flag = false;
        ret2 = false;
//        cantidad = new ArrayList<Integer>();
    }
    public GenerarReporteClientes(List<Object[]> lista_, List<Integer> cantidad_){
        this.lista = lista_;
//        this.cantidad = cantidad_;
        //total = 0;
    }
    public boolean esnormal(int codigo){
        for(int i = 0 ; i<lista_normales.size(); i++){
            if(codigo == lista_normales.get(i))
                return true;
        }
        return false;
    }
    @Override
    public boolean next() throws JRException {
        System.out.println(lista.size() + " " + lista2.size());
        ret = ++indiceProductoActual<lista.size();
        if(!ret){
            ret2 =  ++indiceProductoActual2<lista2.size();
           // System.out.println((int)lista2.get(indiceProductoActual2)[0] +" "+ (String)lista2.get(indiceProductoActual2)[2]); 
            return ret2;//To change body of generated methods, choose Tools | Templates.
        
        }
        System.out.println((int)lista.get(indiceProductoActual)[0] +" "+ (String)lista.get(indiceProductoActual)[2]);
        return ret;
    }

    @Override
    public Object getFieldValue(JRField jrf){
       Object valor = null;
       //if(!flag){
       try{
            if(ret && "codigo1".equals(jrf.getName())){
                valor = (int)lista.get(indiceProductoActual)[0];
            }else if(ret && ("nombre").equals(jrf.getName())){
                valor = (String)lista.get(indiceProductoActual)[1];
            }else if(ret && ("aPaterno").equals(jrf.getName())){
                valor = (String)lista.get(indiceProductoActual)[2];
            }else if(ret && ("aMaterno").equals(jrf.getName())){
                valor = (String)lista.get(indiceProductoActual)[3];
            }else if(ret && ("fechaCompra").equals(jrf.getName())){
    //            total += cantidad.get(indiceProductoActual)*lista.get(indiceProductoActual).getPrecio();
                valor = (lista.get(indiceProductoActual)[4]).toString();
                
            }else if(ret && ("total").equals(jrf.getName())){
                valor = ((Double)lista.get(indiceProductoActual)[5]).toString();
            
            }else if(ret2 && ("codigo2".equals(jrf.getName())/* && !esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
                valor = (int)lista2.get(indiceProductoActual2)[0];
            }else if(ret2 && (("ruc").equals(jrf.getName())/* &&!esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
                valor = (String)lista2.get(indiceProductoActual2)[1];
            }else if(ret2 && (("razon").equals(jrf.getName()) /*&& !esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
                valor = (String)lista2.get(indiceProductoActual2)[2];
            }else if(ret2 && (("representacion").equals(jrf.getName()) /*&& !esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
                valor = (String)lista2.get(indiceProductoActual2)[3];
            }else if(ret2 && (("fechaCompra2").equals(jrf.getName()) /*&& !esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
    //            total += cantidad.get(indiceProductoActual)*lista.get(indiceProductoActual).getPrecio();
                valor = ((String)lista2.get(indiceProductoActual2)[4]).toString();
            }else if(ret2 && (("total2").equals(jrf.getName()) /*&& !esnormal((int)lista2.get(indiceProductoActual2)[0])*/)){
                valor = ((Double)lista2.get(indiceProductoActual2)[5]).toString();
            }else if(("nombreVendedor").equals(jrf.getName())){
                valor = nombreVendedor;
            }
            return valor;
       }catch(Exception ex){
           System.out.println(ex.getMessage());
       }
       return null;
       //}
       //return null;
    }
    public void addProducto(Object[] obj/*, int cantidad*/)
    {
        if(!flag)
            this.lista.add(obj);
        else
            this.lista2.add(obj);
    }
    public void changeQuery(){
        flag = true;
    }
  
}
