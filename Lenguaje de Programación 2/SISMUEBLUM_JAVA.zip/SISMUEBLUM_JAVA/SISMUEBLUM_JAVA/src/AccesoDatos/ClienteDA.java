/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.*;
import Seguridad.ErrorLog;
import java.sql.*;
import java.util.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Lucks
 */
public class ClienteDA {
    
    public ArrayList<Juridico> listarCliJ(){
        ArrayList<Juridico> list = new ArrayList<>();
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "CALL LISTAR_CLIENTES_JURIDICOS()";
                CallableStatement st = con.prepareCall(query);
                ResultSet rs = st.executeQuery();
                while(rs.next()){
                    int cod = rs.getInt("codigoCliente");
                    String ruc = rs.getString("ruc");
                    String razon = rs.getString("razon");
                    String rep = rs.getString("representante");
                    String tlf = rs.getString("telefono");
                    String correo = rs.getString("correo");
                    String dir = rs.getString("direccion");
                    int codV = rs.getInt("idVendedor");
                    Vendedor v = new Vendedor(codV);
                    
                    Juridico auxJ = new Juridico(ruc,razon,rep,cod,tlf,correo,dir,v);
                    list.add(auxJ);
                }
                rs.close();
                con.close();
                return list;
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        
        return null;
    }
    
    public ArrayList<Venta> historialCliente(Cliente c){
        ArrayList<Venta> list = new ArrayList<>();
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL HISTORIAL_DE_COMPRAS_CLIENTE(?)}";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_CODIGO_CLIENTE", c.getCodigoCliente());
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Venta v = new Venta();
                
                int cod = rs.getInt("idVenta");
                v.setIdVenta(cod);
                double subT = rs.getDouble("subToltal");
                v.setSubToltal(subT);
                double tot = rs.getDouble("total");
                v.setTotal(tot);
                v.setFechaCompra(rs.getDate("fechaCompra"));
                String tipo = rs.getString("tipoDoc");
                switch (tipo) {
                    case "Factura":
                        v.setTipoDoc(TipoDocDeVenta.Factura);
                        list.add(v);
                        break;
                    case "Boleta":
                        v.setTipoDoc(TipoDocDeVenta.Boleta);
                        list.add(v);
                        break;
                    case "Cotizacion":
                        v.setTipoDoc(TipoDocDeVenta.Cotizacion);
                        list.add(v);
                        break;
                    default:
                        break;
                }
            }
            rs.close();
            con.close();
            return list;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
a                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }      
        return null;
    }
    public ArrayList<Natural> listarCliN(){
    ArrayList<Natural> list = new ArrayList<>();
    try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "CALL LISTAR_CLIENTES_NATURAL()";
            CallableStatement st = con.prepareCall(query);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int cod = rs.getInt("codigoCliente");
                String nom = rs.getString("nombre");
                String aPat = rs.getString("apellidoPaterno");
                String aMat = rs.getString("apellidoMaterno");
                String dni = rs.getString("dni");
                String tlf = rs.getString("telefono");
                String correo = rs.getString("correo");
                String dir = rs.getString("direccion");
                int codV = rs.getInt("idVendedor");
                Vendedor v = new Vendedor(codV);

                Natural auxN = new Natural(nom,aPat,aMat,dni,cod,tlf,correo,dir,v);
                list.add(auxN);
            }
            rs.close();
            con.close();
            return list;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }

    return null;
    }
    public void agregarClienteN(Natural n){
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "{CALL AGREGAR_CLIENTE_NATURAL(?,?,?,?,?,?,?,?)}";                     
                CallableStatement st = (CallableStatement)con.prepareCall(query);
                st.setString("_NOMBRES", n.getNombre());
                st.setString("_APELLIDO_PATERNO", n.getApellidoPaterno());
                st.setString("_APELLIDO_MATERNO", n.getApellidoMaterno());
                st.setString("_DNI", n.getDni());
                st.setString("_TELEFONO", n.getTelefono()); 
                st.setString("_CORREO", n.getCorreo());
                st.setString("_DIRECCION", n.getDireccion());
                //st.setInt("_COD_VENDEDOR", n.getVendedor().getCodigoUsuario());
                st.registerOutParameter("_CODIGO_CLIENTE", java.sql.Types.INTEGER);
                st.execute();
                int id = st.getInt("_CODIGO_CLIENTE");
                st.close();
                con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    public void agregarClienteJ(Juridico j){
    try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL AGREGAR_CLIENTE_JURIDICO(?,?,?,?,?,?,?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);

            st.setString("_RUC", j.getRuc());
            st.setString("_RAZON", j.getRazon());
            st.setString("_REPRESENTANTE", j.getRepresentante());
            st.setString("_TELEFONO", j.getTelefono()); 
            st.setString("_CORREO", j.getCorreo());
            st.setString("_DIRECCION", j.getDireccion());
            //st.setInt("_COD_VENDEDOR", j.getVendedor().getCodigoUsuario());
            st.registerOutParameter("_CODIGO_CLIENTE", java.sql.Types.INTEGER);
            st.execute();
            int id = st.getInt("_CODIGO_CLIENTE");
            st.close();
            con.close();
    }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
    }
    }
    
    
    public void modificarClienteN(Natural n){
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL MODIFICAR_CLIENTE_NATURAL(?,?,?,?,?,?,?,?)}";                     
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setInt("_CODIGO_CLIENTE", n.getCodigoCliente());
            st.setString("_NOMBRES", n.getNombre());
            st.setString("_APELLIDO_PATERNO", n.getApellidoPaterno());
            st.setString("_APELLIDO_MATERNO", n.getApellidoMaterno());
            st.setString("_DNI", n.getDni());
            st.setString("_TELEFONO", n.getTelefono()); 
            st.setString("_CORREO", n.getCorreo());
            st.setString("_DIRECCION", n.getDireccion());
            st.execute();
            con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }      
    }
    
    public void modificarClienteJ(Juridico j){
          try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL MODIFICAR_CLIENTE_JURIDICO(?,?,?,?,?,?,?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setInt("_CODIGO_CLIENTE", j.getCodigoCliente());
            st.setString("_RUC", j.getRuc());
            st.setString("_RAZON", j.getRazon());
            st.setString("_REPRESENTANTE", j.getRepresentante());
            st.setString("_TELEFONO", j.getTelefono()); 
            st.setString("_CORREO", j.getCorreo());
            st.setString("_DIRECCION", j.getDireccion());
            st.execute();
            con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }      
    }
//    public ArrayList<Cliente> filtrarCliJ() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    public ArrayList<Cliente> filtrarCliN() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
    
    public int buscarClienteN(String datoDni){
        Natural n = new Natural();
        n.setDni("");
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL BUSCAR_CLIENTE_NATURAL_POR_ATRIBUTO(?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setString("_DNI", datoDni);
            st.execute();
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                n.setDni(rs.getString("dni"));
            }
            con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        } 
        if(n.getDni().equals(datoDni)){
                return 1;
        }
        else{
            return 0;
        }
    }
    
    public int buscarClienteJ(String datoRuc){
        Juridico j = new Juridico();
        j.setRuc("");
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL BUSCAR_CLIENTE_JURIDICO_POR_ATRIBUTO(?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setString("_RUC", datoRuc);
            st.execute();
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                j.setRuc(rs.getString("ruc"));
            }
            con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        } 
        if(j.getRuc().equals(datoRuc)){
            return 1;
        }
        else{
            return 0;
        }
    }
    
    public int verificarClienteVendedor(int codV, int codC){
        int resp = 0;
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL VERIFICAR_CLIENTE_VENDEDOR(?,?,?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setInt("_COD_VENDEDOR", codV);
            st.setInt("_COD_CLIENTE", codC);
            st.registerOutParameter("RESULTADO", java.sql.Types.INTEGER);
            st.execute();
            resp = st.getInt("RESULTADO");
            con.close();
            return resp;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        return resp;
    }
    
    public void reasignarClienteVendedor(int codV, int codC){
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "{CALL REASIGNAR_CLIENTE_VENDEDOR(?,?)}";                
            CallableStatement st = (CallableStatement)con.prepareCall(query);
            st.setInt("_COD_VENDEDOR", codV);
            st.setInt("_COD_CLIENTE", codC);
            st.execute();
            con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public ArrayList<DetalleVenta> productosCliente(int idV) throws SQLException{
        ArrayList<DetalleVenta> lista = new ArrayList<>();
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "{CALL LISTAR_PRODUCTOS_VENTA(?)}";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_CODIGO_VENTA", idV);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                //boolean activo = rs.getBoolean("activo");
                //if (activo){ 
                    DetalleVenta d = new DetalleVenta();
                    Producto p = new Producto();
                    p.setCodigo(rs.getInt("codigo"));
                    p.setNombre(rs.getString("nombre"));
                    p.setFamilia(rs.getString("familia"));
                    p.setPrecio(rs.getDouble("precio")*(1-rs.getDouble("descuento")));
                    p.setProveedor(obtenerProveedor(rs.getInt("Proveedor_idProveedor"), con));
                    p.setColor(obtenerColor(rs.getInt("Color_idColor"), con));
                    p.setUnidad(obtenerUnidadMedida(rs.getInt("UnidadMedida_idUnidadMedida"), con));
                    p.setActivo(rs.getBoolean("activo"));
                    d.setCantidad(rs.getDouble("cantidad"));
                    d.setProducto_codigo(p);
                    lista.add(d);
                //}
                
            }
            rs.close();
            con.close();
            
            return lista;    
        }
    }
    
    public String obtenerColor(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_COLOR(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombreColor");
        rs.close();

        return resultado;
    }
    
    public String obtenerProveedor(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_PROVEEDOR(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombre");
        rs.close();

        return resultado;
    }
    public String obtenerUnidadMedida(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_UNIDAD(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombreMedida");
        rs.close();

        return resultado;
    }
    
    public ArrayList<Natural> filtrarNatural(String Pdni,String Pnombre,String PapPat)throws SQLException {
        try{
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "CALL FILTRAR_CLIENTE_NATURAL(?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_DNI",Pdni );
            st.setString("_NOMBRE", Pnombre);
            st.setString("_APPAT", PapPat);
            ResultSet rs = st.executeQuery();
            ArrayList <Natural> lista = new ArrayList<>();
            while(rs.next()){
                int cod = rs.getInt("codigoCliente");
                String nom = rs.getString("nombre");
                String aPat = rs.getString("apellidoPaterno");
                String aMat = rs.getString("apellidoMaterno");
                String dni = rs.getString("dni");
                String tlf = rs.getString("telefono");
                String correo = rs.getString("correo");
                String dir = rs.getString("direccion");
                int codV = rs.getInt("idVendedor");
                Vendedor v = new Vendedor(codV);

                Natural auxN = new Natural(nom,aPat,aMat,dni,cod,tlf,correo,dir,v);
                lista.add(auxN);
            }
            rs.close();
            con.close();
            return lista;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }

    return null;
    }

    public ArrayList<Juridico> filtrarJuridico(String Pruc,String Prazon,String Prep)throws SQLException {
        ArrayList<Juridico> lista = new ArrayList<>();
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "CALL FILTRAR_CLIENTE_JURIDICO(?,?,?)";
                CallableStatement st = con.prepareCall(query);
                st.setString("_RUC",Pruc );
                st.setString("_RS", Prazon);
                st.setString("_REP", Prep);
                ResultSet rs = st.executeQuery();
                while(rs.next()){
                    int cod = rs.getInt("codigoCliente");
                    String ruc = rs.getString("ruc");
                    String razon = rs.getString("razon");
                    String rep = rs.getString("representante");
                    String tlf = rs.getString("telefono");
                    String correo = rs.getString("correo");
                    String dir = rs.getString("direccion");
                    int codV = rs.getInt("idVendedor");
                    Vendedor v = new Vendedor(codV);
//                    System.out.println(ruc);
                    Juridico auxJ = new Juridico(ruc,razon,rep,cod,tlf,correo,dir,v);
                    lista.add(auxJ);
                }
                rs.close();
                con.close();
                return lista;
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        
        return null;
    }
}
