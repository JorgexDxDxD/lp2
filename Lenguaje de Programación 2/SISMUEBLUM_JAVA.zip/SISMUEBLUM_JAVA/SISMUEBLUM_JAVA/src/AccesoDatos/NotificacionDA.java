/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.Notificacion;
import Seguridad.ErrorLog;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author ferp93
 */
public class NotificacionDA {
    public ArrayList<Notificacion> obtenerNotificacioneDeStock(){
        ArrayList<Notificacion> lista = new ArrayList<>();
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL LISTAR_PRODUCTOS_STOCK_MINIMO()";
            CallableStatement st = con.prepareCall(query);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                boolean activo = rs.getBoolean("activo");
                if (activo){ 
                    Notificacion n = new Notificacion();
                    n.redactarMensajeDeStock(rs.getInt("codigo"), rs.getString("nombre"),
                        obtenerProveedor(rs.getInt("Proveedor_idProveedor"), con));
                    lista.add(n);
                }
            }
            rs.close();
            con.close();
            
            
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        return lista;
    }
    public ArrayList<Notificacion> obetenerNotificacionVendedor(){
        ArrayList<Notificacion> lista = new ArrayList<>();
        try(
        Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "select * from Vendedor,Usuario where ((Vendedor.montoVendido>=Vendedor.meta) "
                    + "and Usuario.codigoUsuario = Vendedor.Usuario_codigoUsuario) and Usuario.activo = 1";
            CallableStatement st = con.prepareCall(query);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                double meta = rs.getDouble("meta");
                if(meta==0.0)
                    continue;
                Notificacion n = new Notificacion();
                n.redactarMensajeVendedor(rs.getInt("codigoUsuario"), rs.getString("nombre") + " " +rs.getString("apellidoPaterno"),
                    rs.getDouble("meta"),rs.getDouble("montoVendido"));
                lista.add(n);
                
            }
            rs.close();
            con.close();
            
            
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        return lista;
    }
    public String obtenerProveedor(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_PROVEEDOR(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombre");
        rs.close();

        return resultado;
    }
}
