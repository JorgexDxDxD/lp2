/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Frank7cj
 */
public class UsuarioDA {
    public ArrayList<Usuario> listarGer() throws SQLException{
        ArrayList<Usuario> listaGer = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());){
            String query = "CALL LISTAR_GERENTES()";
            CallableStatement st = con.prepareCall(query);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int codigo = rs.getInt("codigoUsuario");
                String apP = rs.getString("apellidoPaterno");
                String apM = rs.getString("apellidoMaterno");
                String nomb = rs.getString("nombre");
                String email = rs.getString("correo");
                String dni = rs.getString("dni");
                String sexo = rs.getString("sexo");
                Date fecha = rs.getDate("fechaRegistro");
                String username = rs.getString("username");
                String pass = rs.getString("pass");
                int prioridad = rs.getInt("prioridad");
                Usuario auxU = new Gerente(nomb, apP, apM, dni, username, pass, prioridad, fecha, codigo, email, sexo);
                listaGer.add(auxU);
            }
            con.close();
        }
        return listaGer;
    }
    public ArrayList<Usuario> listarGerFilt(String nombre,String apellido,String dniUser,Integer prio) throws SQLException{
        ArrayList<Usuario> listaGer = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL FILTRAR_GERENTES(?,?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_NOMBRE", nombre);
            st.setString("_AP_PATERNO", apellido);
            st.setInt("_PRIORIDAD", prio);
            st.setString("_DNI", dniUser);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int codigo = rs.getInt("codigoUsuario");
                String apP = rs.getString("apellidoPaterno");
                String apM = rs.getString("apellidoMaterno");
                String nomb = rs.getString("nombre");
                String email = rs.getString("correo");
                String dni = rs.getString("dni");
                String sexo = rs.getString("sexo");
                Date fecha = rs.getDate("fechaRegistro");
                String username = rs.getString("username");
                String pass = rs.getString("pass");
                int prioridad = rs.getInt("prioridad");
                Usuario auxU = new Gerente(nomb, apP, apM, dni, username, pass, prioridad, fecha, codigo, email, sexo);
                listaGer.add(auxU);
            }
            con.close();
        }
        return listaGer;
    }
    public void crearGer(Usuario g) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL REGISTRAR_GERENTE(?,?,?,?,?,?,?,?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_DNI", g.getDni());
            st.setString("_NOMBRES", g.getNombre());
            st.setString("_APELLIDO_PATERNO", g.getApellidoPaterno());
            st.setString("_APELLIDO_MATERNO", g.getApellidoMaterno());
            st.setString("_SEXO", g.getSexo());
            st.setString("_CORREO", g.getCorreo());
            st.setString("_USERNAME", g.getUsername());
            st.setString("_PASSWORD", g.getPassword());
            st.setInt("_PRIORIDAD", g.getPrioridad());
            st.execute();
            con.close();
        }
    }
    public void modificarGer(Usuario g) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL MODIFICAR_GERENTE(?,?,?,?,?,?,?,?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID_USUARIO", g.getCodigoUsuario());
            st.setString("_DNI", g.getDni());
            st.setString("_NOMBRE", g.getNombre());
            st.setString("_APELLIDO_PATERNO", g.getApellidoPaterno());
            st.setString("_APELLIDO_MATERNO", g.getApellidoMaterno());
            st.setString("_SEXO", g.getSexo());
            st.setString("_CORREO", g.getCorreo());
            st.setString("_USERNAME", g.getUsername());
            st.setString("_PASSWORD", g.getPassword());
            st.setInt("_PRIORIDAD", g.getPrioridad());
            st.execute();
            con.close();
        }
    }
    public void eliminaGer(int idG) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL ELIMINAR_USUARIO(?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID_USUARIO", idG);
            st.execute();
            con.close();
        }
    }
    
}
