/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.ComponenteKit;
import Modelo.Juridico;
import Modelo.Kit;
import Modelo.Natural;
import Modelo.Producto;
import Modelo.TipoDocDeVenta;
import Modelo.Venta;
import Vista.Venta.auxLineaVenta;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ferp93
 */
public class VentaDA {
    public ArrayList<Producto> listarProductos(String nombreProducto) throws SQLException{
        ArrayList<Producto> lista = new ArrayList<>();
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL BUSCAR_PRODUCTOS(?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_NOMBRE", nombreProducto);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                boolean activo = rs.getBoolean("activo");
                if (activo){ 
                    Producto p = new Producto();
                    
                    p.setCodigo(rs.getInt("codigo"));
                    p.setNombre(rs.getString("nombre"));
                    p.setFamilia(rs.getString("familia"));
                    p.setPrecio(rs.getDouble("precio")*(1-rs.getDouble("descuento")));
                    p.setProveedor(obtenerProveedor(rs.getInt("Proveedor_idProveedor"), con));
                    p.setColor(obtenerColor(rs.getInt("Color_idColor"), con));
                    p.setUnidad(obtenerUnidadMedida(rs.getInt("UnidadMedida_idUnidadMedida"), con));
                    p.setStock(rs.getDouble("Stock"));
                    
                    lista.add(p);
                }
                
            }
            rs.close();
            con.close();
            
            return lista;
        }
    }
    
    public String obtenerColor(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_COLOR(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombreColor");
        rs.close();

        return resultado;
    }
    
    public String obtenerProveedor(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_PROVEEDOR(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombre");
        rs.close();

        return resultado;
    }
    public String obtenerUnidadMedida(int id, Connection con) throws SQLException{
        String query = "CALL BUSCAR_UNIDAD(?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID", id);
        
        ResultSet rs = st.executeQuery();
        String resultado = "Error";
        while(rs.next()) resultado = rs.getString("nombreMedida");
        rs.close();

        return resultado;
    }
    
    public ArrayList<Juridico> listarJuridicos(String nombreCliente, int idVendedor) throws SQLException{
        ArrayList<Juridico> lista = new ArrayList<>();
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL BUSCAR_CLIENTES_JURIDICOS(?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_NOMBRE", nombreCliente);
            st.setInt("_ID_VENDEDOR", idVendedor);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Juridico j = new Juridico();
                j.setCodigoCliente(rs.getInt("codigoCliente"));
                j.setRazon(rs.getString("razon"));
                j.setRuc(rs.getString("ruc"));
                j.setDireccion(rs.getString("direccion"));
                j.setCorreo(rs.getString("correo"));
                j.setTelefono(rs.getString("telefono"));
                
                lista.add(j);
            }
            rs.close();
            con.close();
            
            return lista;
        }
    }
    
    public ArrayList<Natural> listarNaturales(String nombreCliente, int idVendedor) throws SQLException{
        ArrayList<Natural> lista = new ArrayList<>();
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL BUSCAR_CLIENTES_NATURALES(?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_NOMBRE", nombreCliente);
            st.setInt("_ID_VENDEDOR", idVendedor);

            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Natural n = new Natural();
                n.setCodigoCliente(rs.getInt("codigoCliente"));
                n.setNombre(rs.getString("nombre"));
                n.setApellidoPaterno(rs.getString("apellidoPaterno"));
                n.setApellidoMaterno(rs.getString("apellidoMaterno"));
                n.setDni(rs.getString("dni"));
                n.setDireccion(rs.getString("direccion"));
                n.setCorreo(rs.getString("correo"));
                n.setTelefono(rs.getString("telefono"));

                lista.add(n);
            }
            rs.close();
            con.close();
            
            return lista;
        }
    }
    
    public int registrarVenta(Venta venta) throws SQLException{
        try (
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL REGISTRAR_VENTA(?,?,?,?,?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_TIPODOC", venta.getTipoDoc().name());
            st.setDouble("_SUBTOTAL", venta.getSubToltal());
            System.out.println(venta.getTotal());
            st.setDouble("_TOTAL", venta.getTotal()); //debuggggggg - está registrando un cero
            st.setString("_DIRECCION", venta.getCliente_codigoCliente().getDireccion());
            st.setInt("_ID_CLIENTE", venta.getCliente_codigoCliente().getCodigoCliente());
            st.setInt("_ID_VENDEDOR", venta.getVendedor_Usuario_codigoUsuario1().getCodigoUsuario());
            st.registerOutParameter("_ID_VENTA", java.sql.Types.INTEGER);
            st.execute();
            int id = st.getInt("_ID_VENTA");
            registrarDetalleVenta(id, venta, con);
            if (venta.getTipoDoc()!=TipoDocDeVenta.Cotizacion)
                incrementarMontoVendido(venta.getVendedor_Usuario_codigoUsuario1().getCodigoUsuario(), venta.getSubToltal(), con);
            con.close();
            
            return id;
        }
    }
    
    public void registrarDetalleVenta(int id, Venta venta,Connection con) throws SQLException{
        for(auxLineaVenta linea: venta.getAuxDetalleVenta()){
            String query = "CALL REGISTRAR_DETALLEVENTA(?,?,?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID_VENTA", id);
            st.setInt("_ID_PRODUCTO", linea.getProducto().getCodigo());
            st.setInt("_ID_VENDEDOR", venta.getVendedor_Usuario_codigoUsuario1().getCodigoUsuario());
            st.setDouble("_CANTIDAD", linea.getCantidad());
            st.execute();
            
            if (venta.getTipoDoc()!=TipoDocDeVenta.Cotizacion){
                decrecerStock(linea.getProducto().getCodigo(), linea.getCantidad(), con);
                
//                try{
//                    for ( ComponenteKit j : ((Kit)linea.getProducto()).getComponenteKit()){
//                        decrecerStock_1_Componente_Kit(j.getProducto_codigo().getCodigo(),j.getCantidad(),con);
//                    }
//                }
//                catch(Exception e){
//                    System.out.println(e.getMessage());
//                }
            }
        }
    }
    
    public void decrecerStock (int idProducto, double stockADecrecer, Connection con) throws SQLException{
        String query = "CALL DECRECER_STOCK_PRODUCTO(?,?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID_PRODUCTO", idProducto);
        st.setDouble("_STOCK_A_RESTAR", stockADecrecer);
        st.execute();
    }
    
    public void incrementarMontoVendido (int idVendedor, double montoASumar, Connection con) throws SQLException{
        String query = "CALL INCREMENTAR_MONTO_VENDIDO(?,?)";
        CallableStatement st = con.prepareCall(query);
        st.setInt("_ID_VENDEDOR", idVendedor);
        st.setDouble("_MONTO_A_SUMAR", montoASumar);
        st.execute();
    }
    
    public double obtenerMontoVendido(int id) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                accesoBaseDeDatos.getHost(),
                accesoBaseDeDatos.getUsername(),
                accesoBaseDeDatos.getPassword());) {
        
            String query = "CALL OBTENER_MONTO_VENDIDO(?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID", id);

            ResultSet rs = st.executeQuery();
            double resultado = -1;
            while(rs.next()) resultado = rs.getDouble("montoVendido");
            rs.close();
            
            con.close();
            return resultado;
        }
    }

//    private void decrecerStock_1_Componente_Kit(int codigo, double cantidad, Connection con) throws SQLException {
//        String query = "CALL DECRECER_STOCK_1_COMPONENTE_KIT(?,?)";
//        CallableStatement st = con.prepareCall(query);
//        st.setInt("_ID_PRODUCTO", codigo);
//        st.setDouble("_STOCK_A_RESTAR", cantidad);
//        st.execute();
//    }
}
