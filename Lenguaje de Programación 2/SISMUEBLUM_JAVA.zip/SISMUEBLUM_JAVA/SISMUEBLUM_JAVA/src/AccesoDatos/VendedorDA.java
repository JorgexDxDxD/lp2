/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.Local;
import Modelo.Vendedor;
import Seguridad.ErrorLog;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Alvaro
 */
public class VendedorDA {
    private double MontoAcumulado_INIT = 0.0;
    public ArrayList<Vendedor> listarList(){
        ArrayList<Vendedor> list = new ArrayList<>();
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "CALL LISTAR_VENDEDORES()";
                CallableStatement st = con.prepareCall(query);
                ResultSet rs = st.executeQuery();
                while(rs.next()){
                    int codigo = rs.getInt("codigoUsuario");
//                    int meta = rs.getInt("meta");
//                    double eficiencia = rs.getDouble("eficiencia");
                    String informacion = rs.getString("informacion");
                    String apP = rs.getString("apellidoPaterno");
                    String apM = rs.getString("apellidoMaterno");
                    String nomb = rs.getString("nombre");
                    String email = rs.getString("correo");
                    String dni = rs.getString("dni");
                    String sexo = rs.getString("sexo");
                    Date fecha = rs.getDate("fechaRegistro");
                    String username = rs.getString("username");
                    String pass = rs.getString("pass");
                    String telefono = rs.getString("telefono");
                    String correo = rs.getString("correo");
                    double meta = rs.getDouble("meta");
                    double eficiencia = rs.getDouble("eficiencia");
                    String domicilio = rs.getString("domicilio");
                    String seguro = rs.getString("seguro");
                    double montoAcumulado = rs.getDouble("montoVendido");
                    /*
                     Vendedor(String nombre, String apellidoPaterno,String apellidoMaterno,
                String dni, String username,String password, Date fecha,
                int codigo, String email, String sexo, String seguro,String domicilio,
                String informacion)
                    */
                    Vendedor auxU = new Vendedor(nomb, apP, apM, dni, username, pass, fecha, codigo, email, sexo,seguro,domicilio,informacion);
                    auxU.setTelofono(telefono);
                    auxU.setCorreo(correo);
                    Local lo = new Local();
                    lo.setIdLocal(rs.getInt("Local_idLocal"));
                    auxU.setLocal_idLocal(lo);
                    auxU.setMeta(meta);
                    auxU.setEficiencia(eficiencia);
                    auxU.setMontoAsignado(montoAcumulado);
                    auxU.setHorasMensuales(rs.getInt("horasMensuales"));
                    list.add(auxU);
                }
                rs.close();
                con.close();
                return list;
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        
        return null;
    }
    public int reiniciarMonto(int id){
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "update Vendedor set montoVendido="+MontoAcumulado_INIT+" where Vendedor.Usuario_codigoUsuario = (?)";
                CallableStatement st = con.prepareCall(query);
                st.setInt(1, id);
                st.execute();
                con.close();
                return 1;
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        return -1;
    }
    public int reiniciarMontoAll(){
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "update Vendedor set montoVendido="+MontoAcumulado_INIT;
                CallableStatement st = con.prepareCall(query);
               st.execute();
                con.close();
                return 1;
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
        return -1;
    }
    public void eliminarV(int id){
            try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "CALL ELIMINAR_USUARIO(?)";
                CallableStatement st = con.prepareCall(query);
                st.setInt("_ID_USUARIO", id);
                st.execute();
                con.close();
            }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
            }
    }
    
    public int update(Vendedor g){
        int index = 0;
        int index2 = 0;
        try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "Update Usuario SET nombre = '" + g.getNombre() +
                               "', apellidoPaterno='"+g.getApellidoPaterno()+"',"
                        + "apellidoMaterno='"+g.getApellidoMaterno()+"',"
                        + "username='"+g.getUsername()+"'"+",pass='"+g.getPassword()+"',"
                        + "correo='"+g.getCorreo()+"'  Where codigoUsuario="+g.getCodigoUsuario()+';';                
                Statement st = con.createStatement();
                index = st.executeUpdate(query);
                 String query2 = "Update Vendedor SET meta=" + g.getMeta()+",eficiencia="+g.getEficiencia()+","+
                                    "informacion='"+g.getInformacion()+"',"+"seguro='"+g.getSeguro()+"',"
                                    + "domicilio='"+g.getDomicilio()+"',"+"telefono='"+g.getTelofono()+"',"+
                                        "horasMensuales="+g.getHorasMensuales()+",Local_idLocal="+g.getLocal_idLocal().getIdLocal() +
                                            " Where Usuario_codigoUsuario=" +g.getCodigoUsuario()+';';
                index = st.executeUpdate(query2);
               //System.out.println(query2);
                
                
                st.close();
                con.close();
                return index;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        
        return index;
    }
    
    public void crearVen(Vendedor g){
         try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "{CALL REGISTRAR_VENDEDOR(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";                
                CallableStatement st = (CallableStatement)con.prepareCall(query);
                
                
                
                st.setString("_DNI", g.getDni());
                st.setString("_NOMBRES", g.getNombre());
                st.setString("_APELLIDO_PATERNO", g.getApellidoPaterno());
                st.setString("_APELLIDO_MATERNO", g.getApellidoMaterno());
                st.setString("_SEXO", g.getSexo());
                
                st.setString("_CORREO", g.getCorreo());
                st.setString("_USERNAME", g.getUsername());
                st.setString("_PASSWORD", g.getPassword());
                st.setInt("_PRIORIDAD", g.getPrioridad());
                st.setDouble("_META", g.getMeta());
                
                st.setDouble("_EFICIENCIA", g.getEficiencia());
                st.setString("_INFORMACION", g.getInformacion());
                st.setString("_SEGURO", g.getSeguro());
                
                st.setString("_DOMICILIO", g.getDomicilio());
                st.setString("_TELEFONO", g.getTelofono());                       
                
                //System.out.println("Conexion2");
                st.setInt("_LOCAL_ID", g.getLocal_idLocal().getIdLocal());
                //System.out.println("Conexion3");
                
                
                //System.out.println("Conexion3");
                st.registerOutParameter("_ID_USUARIO", java.sql.Types.INTEGER);
                //System.out.println("Local  " + g.getLocal_idLocal().getIdLocal());
                st.execute();
                int id = st.getInt("_ID_USUARIO");
                System.out.println("Se creo usuario con ID : " +id);
                st.close();
                con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
