/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.Local;
import Modelo.Vendedor;
import Seguridad.ErrorLog;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author alulab14
 */
public class LocalDA {
    public void LocalDA(){}
    public ArrayList<Local> getLista(){
        ArrayList<Local> lista = new ArrayList<Local>();
        try{ 
            Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
            String query = "CALL LISTA_LOCAL()";
            CallableStatement st = con.prepareCall(query);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                int id = rs.getInt("idLocal");
                String dir = rs.getString("direccion");
                String tel = rs.getString("telefono");
                
                Local lo = new Local();
                lo.setIdLocal(id);
                lo.setTelefono(tel);
                lo.setDireccion(dir);
//                System.out.println(lo.getIdLocal() + " " +lo.getDireccion() + " " + lo.getTelefono());
                lista.add(lo);
            }
            con.close();
            rs.close();
            st.close();
            return lista;
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
     public void crearVen(Vendedor g){
        try{
                Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());
                String query = "{CALL REGISTRAR_VENDEDOR(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";                
                CallableStatement st = (CallableStatement)con.prepareCall(query);
                
                
                
                st.setString("_DNI", g.getDni());
                st.setString("_NOMBRES", g.getNombre());
                st.setString("_APELLIDO_PATERNO", g.getApellidoPaterno());
                st.setString("_APELLIDO_MATERNO", g.getApellidoMaterno());
                st.setString("_SEXO", g.getSexo());
                
                st.setString("_CORREO", g.getCorreo());
                st.setString("_USERNAME", g.getUsername());
                st.setString("_PASSWORD", g.getPassword());
                st.setInt("_PRIORIDAD", g.getPrioridad());
                st.setDouble("_META", g.getMeta());
                
                st.setDouble("_EFICIENCIA", g.getEficiencia());
                st.setString("_INFORMACION", g.getInformacion());
                st.setString("_SEGURO", g.getSeguro());
                
                st.setString("_DOMICILIO", g.getDomicilio());
                st.setString("_TELEFONO", g.getTelofono());                       
                
                System.out.println("Conexion2");
                st.setInt("_LOCAL_ID", g.getLocal_idLocal().getIdLocal());
                System.out.println("Conexion3");
                
                
                System.out.println("Conexion3");
                st.registerOutParameter("_ID_USUARIO", java.sql.Types.INTEGER);
                System.out.println("Local  " + g.getLocal_idLocal().getIdLocal());
                st.execute();
                int id = st.getInt("_ID_USUARIO");
                System.out.println(id);
                st.close();
                con.close();
        }catch(Exception ex){
                ErrorLog.registrarError(ex.getMessage());
                JOptionPane.showMessageDialog(null,ex.getMessage(), "Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}
