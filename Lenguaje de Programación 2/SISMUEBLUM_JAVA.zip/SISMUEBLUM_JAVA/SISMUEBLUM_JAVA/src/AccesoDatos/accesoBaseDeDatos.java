/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

/**
 *
 * @author jorge
 */
public class accesoBaseDeDatos {
    public static String HOST=null;
    public  static String username=null;
    public static String password=null;
    public static void setHost(String n){
        HOST = n;
    }
    public static String getHost(){
        return HOST;
    }
    public static void setUsername(String n){
        username=n;
    }
    public static String getUsername(){
        return username;
    }
    public static void setPassword(String n){
        password=n;
    }
    public static String getPassword(){
        return password;
    }
}
