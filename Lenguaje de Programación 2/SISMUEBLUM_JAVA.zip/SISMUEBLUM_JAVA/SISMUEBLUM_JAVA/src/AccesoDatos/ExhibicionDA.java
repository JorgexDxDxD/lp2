/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AccesoDatos;

import Modelo.DetalleProd;
import Modelo.DiaSemana;
import Modelo.Exhibicion;
import Modelo.Juridico;
import Modelo.Natural;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jorge
 */
public class ExhibicionDA {

    public void registrarExhibicion(Exhibicion ex) throws SQLException {
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL REGISTRAR_EXHIBICION(?,?,?,?,?,?,?)";
            
            CallableStatement st = con.prepareCall(query);
            st.setString("_DIA_INI", ex.getDiaIni().toString());
            st.setString("_DIA_FIN", ex.getDiaFin().toString());
            st.setString("_DIRECCION", ex.getDireccion());
            st.setString("_TELEFONO", ex.getTelefono());
            st.setInt("_COD_CLIENTE",ex.getCliente_codigoCliente().getCodigoCliente());
            System.out.println(ex.getFechaIniContrato().getTime());
            System.out.println( new java.sql.Date(ex.getFechaIniContrato().getTime()));
            st.setDate("_FECHA_INICIO_CONTRATO", new java.sql.Date(ex.getFechaIniContrato().getTime()));
            st.registerOutParameter("_ID_LOCAL", java.sql.Types.INTEGER);
            st.execute();
            
            int id_local = st.getInt("_ID_LOCAL");
            for (DetalleProd i : ex.getDetalles()){
                String query2 = "CALL REGISTRAR_DETALLEPROD(?,?,?)";
                CallableStatement st2 = con.prepareCall(query2);
                st2.setInt("_LOCAL", id_local);
                st2.setInt("_CODIGO", i.getProducto_codigo().getCodigo());
                st2.setDouble("_CANTIDAD", i.getCantidad());
                st2.execute();
//                System.out.println( i.getCantidad());
                String query3 = "CALL DECRECER_STOCK_PRODUCTO(?,?)";
                CallableStatement st3 = con.prepareCall(query3);
                st3.setInt("_ID_PRODUCTO", i.getProducto_codigo().getCodigo());
                st3.setDouble("_STOCK_A_RESTAR", i.getCantidad());
                st3.execute();
            }
            con.close();
       }

    }

    public ArrayList<Exhibicion> listarExhibicionesNatural(int activo, String num) throws SQLException {
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL FILTRAR_EXHIBICIONES_NATURAL(?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_ID",num );
            st.setInt("_ACTIVO",activo);
            ResultSet rs =st.executeQuery();
            ArrayList<Exhibicion> lista = new ArrayList<>();
            
            while(rs.next()){
                Natural n = new Natural();
                if(rs.getInt("activo")==1){
                    n.setActivo(true);
                }
                else {
                    n.setActivo(false);
                }
                n.setNombre(rs.getString("nombre"));
                n.setApellidoPaterno(rs.getString("apellidoPaterno"));
                n.setApellidoMaterno(rs.getString("apellidoMaterno"));
                n.setDni(rs.getString("dni"));
                n.setTelefono(rs.getString("telefono"));
                n.setCorreo(rs.getString("correo"));
                n.setDireccion(rs.getString("direccion"));
                n.setCodigoCliente(rs.getInt("Cliente_codigoCliente"));
//                n.setFechaDeRegistro(rs.getDate("fechaDeRegistro"));
                
                Exhibicion ex = new Exhibicion();
                ex.setIdLocal(rs.getInt("Local_idLocal"));
                ex.setCliente_codigoCliente(n);
                ex.setActivo((byte) activo);
                ex.setDiaFin(DiaSemana.valueOf(rs.getString("diaFin")));
                ex.setDiaIni(DiaSemana.valueOf(rs.getString("diaIni")));
                ex.setFechaIniContrato(rs.getDate("fechaInicioContrato"));
                
                lista.add(ex);
            }
            con.close();
            return lista;
        }
    }

    public ArrayList<Exhibicion> listarExhibicionesJuridico(int activo, String num) throws SQLException  {
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL FILTRAR_EXHIBICIONES_JURIDICO(?,?)";
            CallableStatement st = con.prepareCall(query);
            st.setString("_ID",num );
            st.setInt("_ACTIVO",activo);
            ResultSet rs =st.executeQuery();
            ArrayList<Exhibicion> lista = new ArrayList<>();
            
            while(rs.next()){
                Juridico n = new Juridico();
                if(rs.getInt("activo")==1){
                    n.setActivo(true);
                }
                else {
                    n.setActivo(false);
                }
                n.setRazon(rs.getString("razon"));
                n.setRuc(rs.getString("ruc"));
                n.setRepresentante(rs.getString("representante"));
                n.setTelefono(rs.getString("telefono"));
                n.setCorreo(rs.getString("correo"));
                n.setDireccion(rs.getString("direccion"));
                n.setCodigoCliente(rs.getInt("Cliente_codigoCliente"));
//                n.setFechaDeRegistro(rs.getDate("fechaDeRegistro"));
                
                Exhibicion ex = new Exhibicion();
                ex.setIdLocal(rs.getInt("Local_idLocal"));
                ex.setCliente_codigoCliente(n);
                ex.setActivo((byte) activo);
                ex.setDiaFin(DiaSemana.valueOf(rs.getString("diaFin")));
                ex.setDiaIni(DiaSemana.valueOf(rs.getString("diaIni")));
                ex.setFechaIniContrato(rs.getDate("fechaInicioContrato"));
                
                lista.add(ex);
            }
            con.close();
            return lista;
        }
    }

    public void eliminarExhibicion(Exhibicion ex) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL ELIMINAR_EXHIBICION(?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID_EX", ex.getIdLocal());
            st.execute();
            con.close();
        }
    }
        
    public void recuperarExhibicion(Exhibicion ex) throws SQLException{
        try (Connection con = DriverManager.getConnection(
                    accesoBaseDeDatos.getHost(),
                    accesoBaseDeDatos.getUsername(),
                    accesoBaseDeDatos.getPassword());) {
            String query = "CALL RECUPERAR_EXHIBICION(?)";
            CallableStatement st = con.prepareCall(query);
            st.setInt("_ID_EX", ex.getIdLocal());
            st.execute();
            con.close();
        }
    }
        

}
